//
//  MSMSection.h
//  SearchBarHomeWork
//
//  Created by Admin on 05.03.14.
//  Copyright (c) 2014 Sergey Monastyrskiy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MSMSection : NSObject

@property (strong, nonatomic) NSString *index;
@property (strong, nonatomic) NSMutableArray *rowsArray;

@end
