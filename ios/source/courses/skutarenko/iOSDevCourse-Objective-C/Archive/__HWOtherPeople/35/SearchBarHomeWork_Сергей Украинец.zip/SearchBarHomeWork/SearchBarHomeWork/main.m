//
//  main.m
//  SearchBarHomeWork
//
//  Created by Admin on 05.03.14.
//  Copyright (c) 2014 Sergey Monastyrskiy. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MSMAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MSMAppDelegate class]));
    }
}
