//
//  VIRTableSection.m
//  SearchTableHomeWork
//
//  Created by Administrator on 03.02.14.
//  Copyright (c) 2014 Konstantin Kokorin. All rights reserved.
//

#import "VIRTableSection.h"

@implementation VIRTableSection

@end
