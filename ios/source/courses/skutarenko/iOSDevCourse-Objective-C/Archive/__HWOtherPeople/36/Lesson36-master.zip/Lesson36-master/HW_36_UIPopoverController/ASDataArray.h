//
//  ASDataArray.h
//  HW_36_UIPopoverController
//
//  Created by MD on 04.07.15.
//  Copyright (c) 2015 hh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASDataArray : NSObject

@property (strong , nonatomic) NSArray* educationArray;

-(instancetype) init;
@end
