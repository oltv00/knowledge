//
//  UIView+FirstResponder.m
//  HW_36_UIPopoverController
//
//  Created by MD on 05.07.15.
//  Copyright (c) 2015 hh. All rights reserved.
//

#import "UIView+FirstResponder.h"

@implementation UIView (FirstResponder)
- (BOOL) canBecomeFirstResponder{
    return YES;
}
@end
