//
//  ASAppDelegate.h
//  HomeWork45
//
//  Created by Александр Карпов on 08.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
