//
//  ASFollowSubscribeTableViewCell.h
//  HomeWork45
//
//  Created by Александр Карпов on 09.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASFollowSubscribeTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *followerSubscribe;


@end
