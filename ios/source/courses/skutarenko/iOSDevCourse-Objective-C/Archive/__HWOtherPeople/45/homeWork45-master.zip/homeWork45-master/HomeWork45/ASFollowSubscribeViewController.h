//
//  ASFollowSubscribeViewController.h
//  HomeWork45
//
//  Created by Александр Карпов on 09.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASFollowSubscribeViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (strong, nonatomic) NSString *userID;
@property (strong, nonatomic) NSString *method;

@end
