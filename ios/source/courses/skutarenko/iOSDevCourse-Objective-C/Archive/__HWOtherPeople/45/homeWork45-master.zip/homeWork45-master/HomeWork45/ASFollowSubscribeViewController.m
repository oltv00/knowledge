//
//  ASFollowSubscribeViewController.m
//  HomeWork45
//
//  Created by Александр Карпов on 09.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import "ASFollowSubscribeViewController.h"
#import "ASFriendsTableViewCell.h"
#import "ASServerManager.h"
#import "ASUser.h"
#import "UIImageView+AFNetworking.h"

@interface ASFollowSubscribeViewController () <UITableViewDataSource, UITableViewDelegate,UIScrollViewDelegate>

@property (strong, nonatomic) NSMutableArray *followersArray;

@property (assign, nonatomic) BOOL loadingCell;

@end

@implementation ASFollowSubscribeViewController

static NSInteger followersRequest = 20;

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setEdgesForExtendedLayout:UIRectEdgeNone];
    self.followersArray = [NSMutableArray array];
    self.loadingCell = YES;
    [self getFollowersFromServer];
}

#pragma mark - API

-(void) getFollowersFromServer {
    
    [[ASServerManager shareManager] getFollowSubcribMethod:self.method
                                                    offset:[self.followersArray count]
                                                    userId:self.userID
                                                     count:followersRequest onSuccess:^(NSArray *objects) {
                                                         
                                                         [self.followersArray addObjectsFromArray:objects];
                                                         
                                                         [self.tableView reloadData];
                                                         
                                                         self.loadingCell = NO;
                                                         
                                                     } onFailure:^(NSError *error, NSInteger statusCode) {
                                                         
                                                         NSLog(@"error = %@, code = %ld", [error localizedDescription], (long)statusCode);
                                                         
                                                     }];
    
}

#pragma mark - UITableViewDelegate

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
}


#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.followersArray count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    


    
    ASUser *follower = [self.followersArray objectAtIndex:indexPath.row];
    
    ASFriendsTableViewCell * cell;
    
    if ([self.method isEqualToString:@"users.getFollowers"]) {
        
        static NSString *identifier = @"cell";
        
        cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (!cell) {
            cell = [[ASFriendsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        

            cell.firstNameLabel.text = follower.firstName;
            cell.lastNameLabel.text = follower.lastName;
            cell.typePage.text = @" ";

        
        
        
    } else if ([self.method isEqualToString:@"users.getSubscriptions"] && [follower.typePage isEqualToString:@"page"]) {
        
        
        static NSString *identifier = @"cell2";
        
        cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (!cell) {
            cell = [[ASFriendsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        
        
        cell.namePage.text = follower.namePage;
        cell.typePage.text = follower.typePage;
        
        
    }
    else if ([self.method isEqualToString:@"users.getSubscriptions"] && [follower.typePage isEqualToString:@"profile"]) {
        
        
        static NSString *identifier = @"cell";
        
        cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (!cell) {
            cell = [[ASFriendsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        
        
        cell.firstNameLabel.text = follower.firstName;
        cell.lastNameLabel.text = follower.lastName;
        cell.typePage.text = follower.typePage;
        
    }

    
    NSURLRequest *request = [NSURLRequest requestWithURL:follower.imageURL];
    
    __weak ASFriendsTableViewCell *weakCell = cell;
    
    
    [weakCell.imageFriend setImageWithURLRequest:request
                                placeholderImage:nil
                                         success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
                                             
                                             weakCell.imageFriend.image = image;
                                         } failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error) {
                                             
                                         }];

    
    return cell;
}


#pragma mark - UIScrollViewDelegate


- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    
    
    if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height) {
        if (!self.loadingCell) {
            [self getFollowersFromServer];
            self.loadingCell = YES;
        }
    }
}

#pragma mark - Other

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
