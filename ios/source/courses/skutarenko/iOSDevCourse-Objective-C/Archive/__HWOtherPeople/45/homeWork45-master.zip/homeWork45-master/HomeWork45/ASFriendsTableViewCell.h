//
//  ASFriendsTableViewCell.h
//  HomeWork45
//
//  Created by Александр Карпов on 08.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASFriendsTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *firstNameLabel;
@property (strong, nonatomic) IBOutlet UILabel *lastNameLabel;
@property (strong, nonatomic) IBOutlet UIImageView *imageFriend;
@property (strong, nonatomic) IBOutlet UILabel *namePage;
@property (strong, nonatomic) IBOutlet UILabel *typePage;

@end
