//
//  ASProfileViewController.m
//  HomeWork45
//
//  Created by Александр Карпов on 08.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import "ASProfileViewController.h"
#import "ASServerManager.h"
#import "ASUserInfoTableViewCell.h"
#import "ASUserProfile.h"
#import "UIImageView+AFNetworking.h"
#import "ASFollowSubscribeTableViewCell.h"
#import "ASFollowSubscribeViewController.h"
#import "ASWallTableViewCell.h"
#import "ASWall.h"

@interface ASProfileViewController () <UITableViewDelegate, UITableViewDataSource,UIScrollViewDelegate>

@property (strong, nonatomic) ASUserProfile *userProfile;
@property (strong, nonatomic) NSMutableArray *wallArray;

@property (assign, nonatomic) BOOL loadingCell;

@end

static NSInteger wallInfoInRequest = 5;

@implementation ASProfileViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}



- (void)viewDidLoad
{
    
    [super viewDidLoad];
    
    [self getFriendProfileFromServer];
    self.wallArray = [NSMutableArray array];
    self.loadingCell = YES;
    

    
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) getFriendProfileFromServer {
    
    
    [[ASServerManager shareManager] getFriendsInfo:self.friendID onSuccess:^(ASUserProfile *userProfile) {
        
        
        self.userProfile = userProfile;
        
        [self.tableView reloadData];
        
        [self getWallInfo];
        
        self.loadingCell = YES;
        

        
        
    } onFailure:^(NSError *error, NSInteger statusCode) {
        NSLog(@"error = %@, code = %ld", [error localizedDescription], (long)statusCode);
    }];
    
}

- (void) getWallInfo {
    

    
    [[ASServerManager shareManager] getWallPosts:self.friendID
                                          offset:[self.wallArray count]
                                           count:wallInfoInRequest
                                       onSuccess:^(NSArray *objects) {

                                           
                                           
                                           if ([objects count] > 0) {
                                               dispatch_queue_t serialQueue = dispatch_queue_create("com.myapp.queue.wall", NULL);
                                               
                                               int newCount = (int)[self.wallArray count] + (int)[objects count];
                                               
                                               
                                               __block int iObj = 0;
                                               
                                               
                                               for (int i = newCount-(int)[objects count]; i < newCount; i++) {
                                                   dispatch_async(serialQueue, ^{
                                                       

                                                       ASWall *wall = [objects objectAtIndex:iObj];
                                                       iObj ++;
                                                       
                                                       if (wall.imageURL != nil) {
                                                           NSData * dataPostPhoto = [[NSData alloc] initWithContentsOfURL: wall.imageURL];
                                                           wall.wallPhoto = [UIImage imageWithData:dataPostPhoto];

                                                       }
                                                       
                                                       [self.wallArray insertObject:wall atIndex:i];

                                                       
                                                       dispatch_async(dispatch_get_main_queue(), ^{
                                                           /*
                                                           [self.tableView beginUpdates];
                                                           
                                                           [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:i inSection:1]] withRowAnimation:UITableViewRowAnimationFade];
                                                           
                                                           [self.tableView endUpdates];
                                                            
                                                            */
                                                           
                                                           [self.tableView reloadData];

                                                           
                                                           if (iObj == [objects count]) {

                                                               self.self.loadingCell = NO;
                                                           }
                                                           
                                                           
                                                           });
                                                       
                                                   });
                                               }
                                               
                                               
                                           }
                                           

                                           
                                           
                                           
        
    } onFailure:^(NSError *error, NSInteger statusCode) {
        NSLog(@"error = %@, code = %ld", [error localizedDescription], (long)statusCode);
    }];
    
}

#pragma mark - UITableViewDataSource

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    return [NSString stringWithFormat:@" Section%ld",section+1];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {

        return 3;
    }
    else  {

        return [self.wallArray count];
    }
    
    return 0;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"cell";
    static NSString *identifier2 = @"cell2";
    static NSString *identifierWall = @"WallCell";
    static NSString *identifierWall2 = @"WallCell2";
    static NSString *identifierWall3 = @"WallCell3";
    
    
    
    if (indexPath.section == 0 && indexPath.row == 0) {
        
        
        ASUserInfoTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (!cell) {
            cell = [[ASUserInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        
        cell.firstNameLabel.text = self.userProfile.firstName;
        cell.lastNameLabel.text = self.userProfile.lastName;
        NSString *online = [NSString stringWithFormat:@"%@",self.userProfile.offOnLine];
        
        if ([online isEqualToString:@"1"]) {
            cell.offOnLine.text = @"Online";
            cell.offOnLine.textColor = [UIColor greenColor];
            cell.offOnLine.font = [UIFont fontWithName:@"Helvetica-Light" size:14];
            
        } else {
            cell.offOnLine.text = @"Offline";
            cell.offOnLine.textColor = [UIColor grayColor];
            cell.offOnLine.alpha = 0.5;
        }
        
        NSString *maleFemale = [NSString stringWithFormat:@"%@",self.userProfile.sex];
        
        if ([maleFemale isEqualToString:@"1"]) {
            cell.maleFemale.text = @"Female";
            
            
        } else {
            cell.maleFemale.text = @"Male";
            
        }
        
        cell.dateOfBirth.text = self.userProfile.bdate;
        
        cell.countryCity.text = self.userProfile.countryName;
        
        cell.imageProfile.layer.masksToBounds = YES;
        cell.imageProfile.layer.cornerRadius = 50;
        
        
        NSURLRequest *request;
        if (self.userProfile.imageURL) {
            request = [NSURLRequest requestWithURL:self.userProfile.imageURL];
        } else {
            request = [NSURLRequest requestWithURL:self.userProfile.imageURL_100];
        }
        
        
        
        
        [cell.imageProfile setImageWithURLRequest:request
                                 placeholderImage:nil
                                          success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
                                              
                                              cell.imageProfile.image = image;
                                          } failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error) {
                                              
                                          }];
        
        
        
        
        return cell;
        

    }
    if (indexPath.section == 0 && (indexPath.row == 1 || indexPath.row == 2)) {
        
        
        
        ASFollowSubscribeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier2];
        
        if (!cell) {
            cell = [[ASFollowSubscribeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier2];
        }
        
        if (indexPath.row == 1) {
            cell.followerSubscribe.text = @"Followers";
        } else {
            cell.followerSubscribe.text = @"Subscribers";
        }
        
        
        return cell;
        
    }
    if (indexPath.section == 1) {

        
        ASWall *wall = [self.wallArray objectAtIndex:indexPath.row];
        ASWallTableViewCell *cell;
        

        
        
        if (!wall.imageURL && wall.postText) {
            
            
            cell = [tableView dequeueReusableCellWithIdentifier:identifierWall];
            
            if (!cell) {
                cell = [[ASWallTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifierWall];
            }
            
            
            cell.textWallLabel.text = wall.postText;
            
            
            
            cell.textWallLabel.frame = CGRectMake(cell.textWallLabel.frame.origin.x,
                                                  cell.textWallLabel.frame.origin.y,
                                                  cell.textWallLabel.frame.size.width,
                                                  wall.sizeTextLabel - 60);
            
            cell.dateLabel.text = wall.date;
            cell.likesCommentsReposts.text = [NSString stringWithFormat:@"share %@ comments %@ likes %@",wall.repost, wall.comments, wall.likes];
            
            
            
            
        } else if(wall.imageURL !=nil && [wall.postText isEqualToString: @""]) {
            cell = [tableView dequeueReusableCellWithIdentifier:identifierWall2];
            
            if (!cell) {
                cell = [[ASWallTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifierWall2];
            }
            
            cell.dateLabel.text = wall.date;
            cell.likesCommentsReposts.text = [NSString stringWithFormat:@"share %@ comments %@ likes %@",wall.repost, wall.comments, wall.likes];
            
            cell.imageWall.image = nil;
            cell.imageWall.image = wall.wallPhoto;
            

            cell.imageWall.frame = CGRectMake((cell.frame.size.width - wall.wallPhoto.size.width/2)/2,10, wall.wallPhoto.size.width/2, wall.wallPhoto.size.height/2);
            
            
            
            
        } else {
            
            cell = [tableView dequeueReusableCellWithIdentifier:identifierWall3];
            
            if (!cell) {
                cell = [[ASWallTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifierWall3];
            }
            
            
            cell.textWallLabel.text = wall.postText;
            cell.textWallLabel.frame = CGRectMake(cell.textWallLabel.frame.origin.x,
                                                  cell.textWallLabel.frame.origin.y,
                                                  cell.textWallLabel.frame.size.width,
                                                  wall.sizeTextLabel - 30);

            cell.dateLabel.text = wall.date;
            cell.likesCommentsReposts.text = [NSString stringWithFormat:@"share %@ comments %@ likes %@",wall.repost, wall.comments, wall.likes];
            
            cell.imageWall.image = nil;
            cell.imageWall.image = wall.wallPhoto;
            
            cell.imageWall.frame = CGRectMake((cell.frame.size.width - wall.wallPhoto.size.width/2)/2,cell.textWallLabel.frame.origin.y + wall.sizeTextLabel, wall.wallPhoto.size.width/2, wall.wallPhoto.size.height/2);
            
        }
        
        return cell;
        }
    
    
    
    
    
    return nil;

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0 && indexPath.row == 0) {
        return 147;
    }
    if (indexPath.section == 0 && (indexPath.row == 1 || indexPath.row == 2)) {
        return 40;
    } if (indexPath.section == 1) {
        
        ASWall *wall = [self.wallArray objectAtIndex:indexPath.row];
        

     
        if (!wall.imageURL && wall.postText) {
            
            wall.sizeTextLabel = [ASWallTableViewCell heightForText:wall.postText];
            
            return wall.sizeTextLabel;
        }
        if (wall.imageURL !=nil && [wall.postText isEqualToString: @""]) {
            

            
            return wall.wallPhoto.size.height/2 + 40;
        
        
        } else {
            
            wall.sizeTextLabel = [ASWallTableViewCell heightForText:wall.postText];
            
            
            
            return  wall.sizeTextLabel + wall.wallPhoto.size.height/2 + 40;
            
        }
        
    }
    
    return 0;
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:sender];
    
    if ([[segue identifier] isEqualToString:@"followSubscribe"]) {

        ASFollowSubscribeViewController *destination = [segue destinationViewController];
        destination.userID = self.friendID;
        
        if (indexPath.section == 0 && indexPath.row == 1) {
            destination.method = @"users.getFollowers";
           
        } else if (indexPath.section == 0 && indexPath.row == 2) {
            destination.method = @"users.getSubscriptions";
           
        }
        
    }
}


- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}


#pragma mark - UIScrollViewDelegate


- (void)scrollViewDidScroll:(UIScrollView *)scrollView {

        if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height) {

            if (!self.loadingCell) {

                [self getWallInfo];
                self.loadingCell = YES;
            
        }

    }
    
}

@end
