//
//  ASServerManager.h
//  HomeWork45
//
//  Created by Александр Карпов on 08.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASUserProfile.h"

@interface ASServerManager : NSObject

+(ASServerManager*) shareManager;


- (void) getFriendsOffset:(NSInteger) offset
                    count:(NSInteger) count
                onSuccess:(void(^)(NSArray *friends)) success
                onFailure:(void(^)(NSError* error, NSInteger statusCode)) failure;

- (void) getFriendsInfo:(NSString*) idFriend
              onSuccess:(void(^)(ASUserProfile *userProfile)) success
              onFailure:(void(^)(NSError* error, NSInteger statusCode)) failure;



-(void) getFollowSubcribMethod:(NSString*) method
                        offset:(NSInteger) offset
                        userId:(NSString*) userId
                         count:(NSInteger) count onSuccess:(void(^)(NSArray *objects)) success
                     onFailure:(void(^)(NSError* error, NSInteger statusCode)) failure;

-(void) getWallPosts:(NSString*) ownderId
              offset:(NSInteger) offset
               count:(NSInteger) count
           onSuccess:(void(^)(NSArray *objects)) success
           onFailure:(void(^)(NSError* error, NSInteger statusCode)) failure;

@end
