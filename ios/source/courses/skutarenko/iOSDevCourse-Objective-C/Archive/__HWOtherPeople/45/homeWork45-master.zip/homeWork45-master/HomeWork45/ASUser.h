//
//  ASUser.h
//  HomeWork45
//
//  Created by Александр Карпов on 08.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASUser : NSObject

@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSURL *imageURL;
@property (strong, nonatomic) NSString *userID;
@property (strong, nonatomic) NSString *namePage;
@property (strong, nonatomic) NSString *typePage;

- (id)initWithServerResponce:(NSDictionary*) responceObject;

@end
