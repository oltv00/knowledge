//
//  ASUser.m
//  HomeWork45
//
//  Created by Александр Карпов on 08.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import "ASUser.h"

@implementation ASUser

- (id)initWithServerResponce:(NSDictionary*) responceObject
{
    self = [super init];
    if (self) {
        
        
        self.firstName = [responceObject objectForKey:@"first_name"];
        self.lastName = [responceObject objectForKey:@"last_name"];
        self.userID = [responceObject objectForKey:@"user_id"];
        
        self.namePage = [responceObject objectForKey:@"name"];
        self.typePage = [responceObject objectForKey:@"type"];
        
        NSString *urlString = [responceObject objectForKey:@"photo_100"];
        if (urlString) {
            self.imageURL = [NSURL URLWithString:urlString];
        }
    }
    return self;
}

@end
