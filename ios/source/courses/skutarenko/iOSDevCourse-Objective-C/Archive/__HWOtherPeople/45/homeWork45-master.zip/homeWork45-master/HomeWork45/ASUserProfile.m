//
//  ASUserProfile.m
//  HomeWork45
//
//  Created by Александр Карпов on 09.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import "ASUserProfile.h"

@implementation ASUserProfile

- (id)initWithServerResponce:(NSDictionary*) responceObject
{
    self = [super init];
    if (self) {
        
        self.firstName = [responceObject objectForKey:@"first_name"];
        self.lastName = [responceObject objectForKey:@"last_name"];
        self.userID = [responceObject objectForKey:@"user_id"];
        
        NSString *urlString = [responceObject objectForKey:@"photo_200"];
        if (urlString) {
            self.imageURL = [NSURL URLWithString:urlString];
        }
        
        NSString *urlString_100 = [responceObject objectForKey:@"photo_100"];
        if (urlString_100) {
            self.imageURL_100 = [NSURL URLWithString:urlString_100];
        }
        
        NSString *statusString = [responceObject objectForKey:@"status"];
        if (statusString) {
            self.status = statusString;
        }
        
        NSString* sexString = [responceObject objectForKey:@"sex"];
        if (sexString) {
            self.sex = sexString;
        }
        
        NSString *bdateString = [responceObject objectForKey:@"bdate"];
        if (bdateString) {
            
            NSString* bdateStringTrasform = [self trasformDateOfBirth:bdateString];
            
            self.bdate = bdateStringTrasform;
        }
        
        NSString *countryString = [responceObject objectForKey:@"country"];
        if (countryString) {
            self.country = countryString;
        }
        
        NSString *cityString = [responceObject objectForKey:@"city"];
        if (cityString) {
            self.city = cityString;
        }
        
        self.offOnLine = [responceObject objectForKey:@"online"];
        
        NSString *countryNameString = [responceObject objectForKey:@"countryName"];
        if (countryNameString) {
            self.countryName = countryNameString;
        }
        
        
    }
    return self;
}


-(NSString*) trasformDateOfBirth:(NSString*) string {
    
    NSString *dateString = string;
    NSString *stringDate;
    
    
    
    if ([string length] <= 4) {
        NSDateFormatter *dateFormatterFromStringToNsdate = [[NSDateFormatter alloc] init];
        
        [dateFormatterFromStringToNsdate setDateFormat:@"yyyy"];
        NSDate *dateFromString = [[NSDate alloc] init];
        dateFromString = [dateFormatterFromStringToNsdate dateFromString:dateString];
        
        NSDateFormatter *dateFormatterFromNsdateToString = [[NSDateFormatter alloc] init];
        [dateFormatterFromNsdateToString setDateFormat:@"yyyy"];
        stringDate = [dateFormatterFromNsdateToString stringFromDate:dateFromString];
        
    } else if ([string length] <= 6) {
        
        NSDateFormatter *dateFormatterFromStringToNsdate = [[NSDateFormatter alloc] init];
        
        [dateFormatterFromStringToNsdate setDateFormat:@"M.yyyy"];
        NSDate *dateFromString = [[NSDate alloc] init];
        dateFromString = [dateFormatterFromStringToNsdate dateFromString:dateString];
        
        NSDateFormatter *dateFormatterFromNsdateToString = [[NSDateFormatter alloc] init];
        [dateFormatterFromNsdateToString setDateFormat:@"MMMM yyyy"];
        stringDate = [dateFormatterFromNsdateToString stringFromDate:dateFromString];
        
    } else if ([string length] > 6) {
        
        NSDateFormatter *dateFormatterFromStringToNsdate = [[NSDateFormatter alloc] init];
        
        [dateFormatterFromStringToNsdate setDateFormat:@"d.M.yyyy"];
        NSDate *dateFromString = [[NSDate alloc] init];
        dateFromString = [dateFormatterFromStringToNsdate dateFromString:dateString];
        
        NSDateFormatter *dateFormatterFromNsdateToString = [[NSDateFormatter alloc] init];
        [dateFormatterFromNsdateToString setDateFormat:@"dd MMMM yyyy"];
        stringDate = [dateFormatterFromNsdateToString stringFromDate:dateFromString];
        
    }
        
    
    
    return stringDate;
}

@end
