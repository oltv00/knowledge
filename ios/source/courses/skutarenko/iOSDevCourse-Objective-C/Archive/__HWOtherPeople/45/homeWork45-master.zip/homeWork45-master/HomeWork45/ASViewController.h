//
//  ASViewController.h
//  HomeWork45
//
//  Created by Александр Карпов on 08.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITableView *tableView;



@end
