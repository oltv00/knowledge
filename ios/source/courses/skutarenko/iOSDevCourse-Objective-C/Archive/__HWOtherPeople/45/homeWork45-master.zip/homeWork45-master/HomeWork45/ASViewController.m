//
//  ASViewController.m
//  HomeWork45
//
//  Created by Александр Карпов on 08.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import "ASViewController.h"
#import "ASFriendsTableViewCell.h"
#import "ASServerManager.h"
#import "ASUser.h"
#import "UIImageView+AFNetworking.h"
#import "ASProfileViewController.h"
//#import "ASFriend.h"

@interface ASViewController () <UITableViewDataSource, UITableViewDelegate,UIScrollViewDelegate>

@property (strong, nonatomic) NSMutableArray *friendsArray;
@property (assign, nonatomic) BOOL loadingCell;

@end

@implementation ASViewController

static NSInteger friendsInRequest = 20;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.friendsArray = [NSMutableArray array];
    self.loadingCell = YES;
    [self getFriendsFromServer];
    
    
}


#pragma mark - API


- (void) getFriendsFromServer {
    
    [[ASServerManager shareManager] getFriendsOffset:[self.friendsArray count]
                                               count:friendsInRequest
                                           onSuccess:^(NSArray *friends) {
                                               [self.friendsArray addObjectsFromArray:friends];
                                               
                                               NSMutableArray *newPaths = [NSMutableArray array];
                                               
                                               for (int i = (int)[self.friendsArray count] - (int)[friends count]; i < [self.friendsArray count]; i++) {
                                                   [newPaths addObject:[NSIndexPath indexPathForRow:i inSection:0]];
                                               }
                                               
                                               [self.tableView beginUpdates];
                                               [self.tableView insertRowsAtIndexPaths:newPaths withRowAnimation:UITableViewRowAnimationTop];
                                               [self.tableView endUpdates];
                                               self.loadingCell = NO;
                                               
                                               
                                               
         
                                           }
                                           onFailure:^(NSError *error, NSInteger statusCode) {
                                            NSLog(@"error = %@, code = %ld", [error localizedDescription], (long)statusCode);
                                           }];
    
    
}


#pragma mark - UITableViewDataSource


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [self.friendsArray count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *identifier = @"cell";
    
    ASFriendsTableViewCell *cell = (ASFriendsTableViewCell*)[tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (!cell) {
        cell = [[ASFriendsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
        
        ASUser *friends = [self.friendsArray objectAtIndex:indexPath.row];
        
        cell.firstNameLabel.text = friends.firstName;
        cell.lastNameLabel.text = friends.lastName;
    
    
    
    
    NSURLRequest *request = [NSURLRequest requestWithURL:friends.imageURL];
    
    __weak ASFriendsTableViewCell *weakCell = cell;
    
    
    [weakCell.imageFriend setImageWithURLRequest:request
                                placeholderImage:nil
                                         success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
                                             
                                             weakCell.imageFriend.image = image;
                                         } failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error) {
                                             
                                         }];

    
    
    
    return cell;
    
}

#pragma mark - UITableViewDelegate 



- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
}
 


- (BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender {
    NSIndexPath *indexPath = [self.tableView indexPathForCell:sender];
    
    if (indexPath.row == [self.friendsArray count]) {
        return NO;
    }
    
    return YES;
}


- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:sender];
    
    if ([[segue identifier] isEqualToString:@"profile"]) {
       
        
        ASUser *user = [self.friendsArray objectAtIndex:indexPath.row];
        
        ASProfileViewController *destination = [segue destinationViewController];
        destination.friendID = user.userID;
        
    }
    
    
}

#pragma mark - UIScrollViewDelegate


- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height) {
        if (!self.loadingCell) {
            [self getFriendsFromServer];
            self.loadingCell = YES;
        }
    }
}



@end
