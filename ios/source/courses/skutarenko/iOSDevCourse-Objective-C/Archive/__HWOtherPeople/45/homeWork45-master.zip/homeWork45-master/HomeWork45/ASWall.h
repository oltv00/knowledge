//
//  ASWall.h
//  HomeWork45
//
//  Created by Александр Карпов on 11.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASWall : NSObject

@property (strong, nonatomic) NSString *postText;
@property (strong, nonatomic) NSString *date;
@property (strong, nonatomic) NSString *comments;
@property (strong, nonatomic) NSString *likes;
@property (strong, nonatomic) NSString *repost;
@property (strong, nonatomic) NSURL *imageURL;
@property (strong,nonatomic) UIImage *wallPhoto;

@property (assign,nonatomic) NSInteger sizeTextLabel;

- (id)initWithServerResponce:(NSDictionary*) responceObject;

@end
