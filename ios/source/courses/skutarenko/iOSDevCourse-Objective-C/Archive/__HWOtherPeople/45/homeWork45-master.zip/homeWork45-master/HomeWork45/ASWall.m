//
//  ASWall.m
//  HomeWork45
//
//  Created by Александр Карпов on 11.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import "ASWall.h"

@implementation ASWall

- (id)initWithServerResponce:(NSDictionary*) responceObject
{
    self = [super init];
    if (self) {
        
        
        self.postText = [responceObject objectForKey:@"text"];
        
        NSString *dateString = [responceObject objectForKey:@"date"];
        if (dateString) {
            
            NSString* dateStringTrasform = [self getDateFromString:dateString];
            
            self.date = dateStringTrasform;

        }
        
        self.comments = [[responceObject objectForKey:@"comments"]objectForKey:@"count"];
        self.likes = [[responceObject objectForKey:@"likes"]objectForKey:@"count"];
        self.repost = [[responceObject objectForKey:@"reposts"]objectForKey:@"count"];
        
        NSString *urlString = [[responceObject objectForKey:@"photoInfo"] objectForKey:@"photo_604"];
        if (urlString) {
            self.imageURL = [NSURL URLWithString:urlString];
            
        }


    }
    return self;
}

-(NSString*) getDateFromString:(NSString*) date {
    
    NSDateFormatter *dateFormatterFromNsdateToString = [[NSDateFormatter alloc] init];
    [dateFormatterFromNsdateToString setDateFormat:@"dd MMMM yyyy  H:m"];
    
    NSTimeInterval integerDate = [date intValue];
    
    NSDate *dateValue = [NSDate dateWithTimeIntervalSince1970:integerDate];
    
    NSString *dateWithFormat = [dateFormatterFromNsdateToString stringFromDate:dateValue];
    
    
    return dateWithFormat;
}


@end
