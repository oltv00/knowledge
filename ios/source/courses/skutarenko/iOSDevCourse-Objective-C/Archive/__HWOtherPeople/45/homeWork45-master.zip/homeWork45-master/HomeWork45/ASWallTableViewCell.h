//
//  ASWallTableViewCell.h
//  HomeWork45
//
//  Created by Александр Карпов on 11.10.14.
//  Copyright (c) 2014 AK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASWallTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *textWallLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *likesCommentsReposts;
@property (weak, nonatomic) IBOutlet UIImageView *imageWall;

+ (CGFloat) heightForText:(NSString*) text;

@end
