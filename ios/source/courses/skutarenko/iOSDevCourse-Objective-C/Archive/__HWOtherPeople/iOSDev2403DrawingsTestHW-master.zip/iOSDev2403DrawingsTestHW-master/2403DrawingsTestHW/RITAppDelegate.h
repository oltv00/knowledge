//
//  RITAppDelegate.h
//  2403DrawingsTestHW
//
//  Created by Aleksandr Pronin on 13.04.14.
//  Copyright (c) 2014 Aleksandr Pronin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RITAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
