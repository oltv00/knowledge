//
//  main.m
//  2403DrawingsTestHW
//
//  Created by Aleksandr Pronin on 13.04.14.
//  Copyright (c) 2014 Aleksandr Pronin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RITAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RITAppDelegate class]));
    }
}
