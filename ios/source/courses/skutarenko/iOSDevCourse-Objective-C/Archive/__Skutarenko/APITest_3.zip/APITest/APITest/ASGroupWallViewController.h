//
//  ASGroupWallViewController.h
//  APITest
//
//  Created by Oleksii Skutarenko on 14.03.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASGroupWallViewController : UITableViewController

@end
