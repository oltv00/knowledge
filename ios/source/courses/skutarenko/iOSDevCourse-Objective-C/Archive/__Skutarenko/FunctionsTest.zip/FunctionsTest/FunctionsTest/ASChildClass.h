//
//  ASChildClass.h
//  FunctionsTest
//
//  Created by Oleksii Skutarenko on 29.09.13.
//  Copyright (c) 2013 Alex Skutarenko. All rights reserved.
//

#import "ASParentClass.h"

@interface ASChildClass : ASParentClass

@end
