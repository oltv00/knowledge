//
//  ASStudent.m
//  TypesTest
//
//  Created by Oleksii Skutarenko on 09.10.13.
//  Copyright (c) 2013 Alex Skutarenko. All rights reserved.
//

#import "ASStudent.h"

@implementation ASStudent

@end
