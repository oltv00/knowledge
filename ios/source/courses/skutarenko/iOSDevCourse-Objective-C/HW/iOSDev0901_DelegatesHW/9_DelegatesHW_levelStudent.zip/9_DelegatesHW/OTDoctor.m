//
//  OTDoctor.m
//  9_DelegatesHW
//
//  Created by Oleg Tverdokhleb on 02.04.16.
//  Copyright © 2016 Oleg Tverdokhleb. All rights reserved.
//

#import "OTDoctor.h"

@implementation OTDoctor

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.name = @"Doctor";
    }
    return self;
}

#pragma mark - OTPatientDelegate

- (void)patientFeelsBad:(OTPatient *)patient {
    if (!patient.isPatient) {
        NSLog(@"The doctor has a diagnosis");
        NSLog(@"%@ %@ feels bad with temperature = %1.1f", patient.name, patient.lastName, patient.temperature);
    } else {
        NSLog(@"%@ %@ not better with temperature = %1.1f", patient.name, patient.lastName, patient.temperature);
    }
    if (patient.temperature >= 39.f) {
        [patient makeShot];
        [patient howAreYou];
    } else if (patient.temperature < 39.f && patient.temperature >= 37.2f) {
        [patient takePill];
        [patient howAreYou];
    } else {
        [patient shouldRest];
    }
}

@end
