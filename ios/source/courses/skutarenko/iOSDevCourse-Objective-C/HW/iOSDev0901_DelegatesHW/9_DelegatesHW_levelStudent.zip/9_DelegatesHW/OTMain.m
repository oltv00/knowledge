//
//  OTMain.m
//  9_DelegatesHW
//
//  Created by Oleg Tverdokhleb on 02.04.16.
//  Copyright © 2016 Oleg Tverdokhleb. All rights reserved.
//

#import "OTMain.h"
#import "OTPatient.h"
#import "OTDoctor.h"
#import "OTFriend.h"

@implementation OTMain

#pragma mark - LifeCycle

- (void)main {
//    [self startTests];
//    [self levelNoob];
    [self levelStudent];
}

- (void)levelStudent {
    OTDoctor *doctor = [OTDoctor new];
    OTFriend *friend = [OTFriend new];
    for (int i = 0; i < 100; i++) {
        OTPatient *patient = [OTPatient new];
        patient.delegate = arc4random() % 2 ? doctor : friend;
        [patient feelsBad];
    }
}

- (void)levelNoob {
    NSMutableArray *patients = [NSMutableArray array];
    
    OTDoctor *doctor = [[OTDoctor alloc] init];
    
    for (int i = 0; i < 20; i++) {
        OTPatient *patient = [[OTPatient alloc] init];
        patient.delegate = doctor;
        [patients addObject:patient];
    }
    
    for (OTPatient *patient in patients) {
//        NSLog(@"%@ %@ %.1f", patient.name, patient.lastName, patient.temperature);
        [patient feelsBad];
    }
}

#pragma mark - TESTS

- (void)startTests {
    //    [self randTest];
    //    [self arctest];
}

- (void)arctest {
    int yes = 0;
    int no = 0;
    for (int i = 0; i < 1000000; i++) {
        //        NSLog(@"%d", arc4random() % 2);
        if (arc4random() % 2 == YES) {
            yes += 1;
        } else {
            no += 1;
        }
    }
    NSLog(@"YES = %d, NO = %d", yes, no);
}

- (void)randTest {
    for (int i = 0; i < 50; i ++) {
        float randomNum = 36.6 + ((float)rand() / RAND_MAX) * 4.4;
        NSLog(@"%f", randomNum);
    }
}
@end
