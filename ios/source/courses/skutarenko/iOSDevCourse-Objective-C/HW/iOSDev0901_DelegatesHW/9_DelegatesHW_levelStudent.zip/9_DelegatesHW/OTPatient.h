//
//  OTPatient.h
//  9_DelegatesHW
//
//  Created by Oleg Tverdokhleb on 02.04.16.
//  Copyright © 2016 Oleg Tverdokhleb. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol OTPatientDelegate;

@interface OTPatient : NSObject
@property (weak, nonatomic) id <OTPatientDelegate> delegate;
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *lastName;
@property (assign, nonatomic) CGFloat temperature;
@property (assign, nonatomic, getter=isPatient) BOOL isPatient;


- (void)feelsBad;
- (void)howAreYou;
- (void)takePill;
- (void)makeShot;
- (void)shouldRest;

@end

@protocol OTPatientDelegate <NSObject>

@required
@property (strong, nonatomic) NSString *name;
- (void)patientFeelsBad:(OTPatient *)patient;

@end