//
//  AZGroup.h
//  HomeProjectTableEditing
//
//  Created by Alex Alexandrov on 11.01.14.
//  Copyright (c) 2014 Alex Zbirnik. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AZGroup : NSObject

@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSArray *students;

@end
