//
//  main.m
//  HomeProjectTableEditing
//
//  Created by Alex Alexandrov on 11.01.14.
//  Copyright (c) 2014 Alex Zbirnik. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AZAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AZAppDelegate class]));
    }
}
