//
//  AppDelegate.h
//  Lesson36-HOmeWork
//
//  Created by Nick Bibikov on 1/13/15.
//  Copyright (c) 2015 Nick Bibikov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

