//
//  RJInfoViewController.h
//  Lesson36Ex
//
//  Created by Hopreeeeenjust on 01.02.15.
//  Copyright (c) 2015 Hopreeeeenjust. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RJInfoViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *okButton;

- (IBAction)actionOkButtonPushed:(UIButton *)sender;
@end
