//
//  AppDelegate.h
//  MKMapView #37-38
//
//  Created by Евгений Глухов on 23.08.15.
//  Copyright (c) 2015 EGApps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

