//
//  EGMeetingCell.m
//  MKMapView #37-38
//
//  Created by Евгений Глухов on 02.09.15.
//  Copyright (c) 2015 EGApps. All rights reserved.
//

#import "EGMeetingCell.h"

@implementation EGMeetingCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
