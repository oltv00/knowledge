//
//  RJCourse.m
//  Lesson41-44Ex
//
//  Created by Hopreeeeenjust on 16.02.15.
//  Copyright (c) 2015 Hopreeeeenjust. All rights reserved.
//

#import "RJCourse.h"
#import "RJProfessor.h"
#import "RJStudent.h"
#import "RJUniversity.h"


@implementation RJCourse

@dynamic field;
@dynamic name;
@dynamic object;
@dynamic professor;
@dynamic students;
@dynamic university;

@end
