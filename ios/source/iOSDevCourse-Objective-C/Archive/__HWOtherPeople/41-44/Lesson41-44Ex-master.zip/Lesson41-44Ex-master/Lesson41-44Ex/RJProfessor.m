//
//  RJProfessor.m
//  Lesson41-44Ex
//
//  Created by Hopreeeeenjust on 16.02.15.
//  Copyright (c) 2015 Hopreeeeenjust. All rights reserved.
//

#import "RJProfessor.h"
#import "RJCourse.h"
#import "RJUniversity.h"


@implementation RJProfessor

@dynamic firstName;
@dynamic lastName;
@dynamic courses;
@dynamic universities;

@end
