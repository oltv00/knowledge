//
//  RJProfessorController.h
//  Lesson41-44Ex
//
//  Created by Hopreeeeenjust on 16.02.15.
//  Copyright (c) 2015 Hopreeeeenjust. All rights reserved.
//

#import "RJCoreDataTableViewController.h"

@interface RJProfessorController : RJCoreDataTableViewController

- (IBAction)actionAddProfessor:(id)sender;

@end
