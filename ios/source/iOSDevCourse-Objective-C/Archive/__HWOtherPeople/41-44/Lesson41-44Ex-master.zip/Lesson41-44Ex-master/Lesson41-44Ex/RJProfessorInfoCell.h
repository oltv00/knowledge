//
//  RJProfessorInfoCell.h
//  Lesson41-44Ex
//
//  Created by Hopreeeeenjust on 18.02.15.
//  Copyright (c) 2015 Hopreeeeenjust. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RJProfessorInfoCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *professorName;
@property (weak, nonatomic) IBOutlet UILabel *profesorsCourses;
@end
