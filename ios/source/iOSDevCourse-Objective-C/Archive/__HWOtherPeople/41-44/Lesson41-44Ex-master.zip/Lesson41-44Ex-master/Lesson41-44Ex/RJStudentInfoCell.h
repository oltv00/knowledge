//
//  RJStudentInfoCell.h
//  Lesson41-44Ex
//
//  Created by Hopreeeeenjust on 16.02.15.
//  Copyright (c) 2015 Hopreeeeenjust. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RJStudentInfoCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *studentName;
@property (weak, nonatomic) IBOutlet UILabel *studentUniversity;
@property (weak, nonatomic) IBOutlet UILabel *studentCourses;
@property (weak, nonatomic) IBOutlet UILabel *studentScore;
@end
