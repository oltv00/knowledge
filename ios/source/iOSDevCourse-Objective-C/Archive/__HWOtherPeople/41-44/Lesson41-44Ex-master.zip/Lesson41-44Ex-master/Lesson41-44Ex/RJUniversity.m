//
//  RJUniversity.m
//  Lesson41-44Ex
//
//  Created by Hopreeeeenjust on 20.02.15.
//  Copyright (c) 2015 Hopreeeeenjust. All rights reserved.
//

#import "RJUniversity.h"
#import "RJCourse.h"
#import "RJProfessor.h"
#import "RJStudent.h"


@implementation RJUniversity

@dynamic name;
@dynamic city;
@dynamic country;
@dynamic rank;
@dynamic courses;
@dynamic professors;
@dynamic students;

@end
