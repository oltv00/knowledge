//
//  RJUniversitiyController.h
//  Lesson41-44Ex
//
//  Created by Hopreeeeenjust on 15.02.15.
//  Copyright (c) 2015 Hopreeeeenjust. All rights reserved.
//

#import "RJCoreDataTableViewController.h"

@interface RJUniversityController : RJCoreDataTableViewController

- (IBAction)actionAddUniversity:(id)sender;

@end
