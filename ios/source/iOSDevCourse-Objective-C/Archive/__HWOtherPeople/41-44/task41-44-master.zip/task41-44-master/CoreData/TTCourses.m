//
//  TTCourses.m
//  CoreData
//
//  Created by Sergey Reshetnyak on 5/27/14.
//  Copyright (c) 2014 sergey. All rights reserved.
//

#import "TTCourses.h"
#import "TTLecturers.h"
#import "TTUsers.h"


@implementation TTCourses

@dynamic department;
@dynamic name;
@dynamic subject;
@dynamic lecturer;
@dynamic students;

@end
