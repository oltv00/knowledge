//
//  TTLecturers.m
//  CoreData
//
//  Created by Sergey Reshetnyak on 5/27/14.
//  Copyright (c) 2014 sergey. All rights reserved.
//

#import "TTLecturers.h"
#import "TTCourses.h"


@implementation TTLecturers

@dynamic firstName;
@dynamic lastName;
@dynamic course;

@end
