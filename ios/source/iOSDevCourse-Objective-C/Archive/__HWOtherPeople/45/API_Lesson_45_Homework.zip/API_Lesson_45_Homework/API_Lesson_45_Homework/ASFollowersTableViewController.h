//
//  ASFollowersTableViewController.h
//  API_Lesson_45_Homework
//
//

#import <UIKit/UIKit.h>

@interface ASFollowersTableViewController : UITableViewController

-(void) getFollowerFromServerOfUserWithID: (NSInteger) userID;


@end
