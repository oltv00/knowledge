//
//  ASSubscribersTableViewController.h
//  API_Lesson_45_Homework
//
//

#import <UIKit/UIKit.h>

@interface ASSubscribersTableViewController : UITableViewController


-(void) getSubscriberFromServerOfUserWithID: (NSInteger) userID;



@end
