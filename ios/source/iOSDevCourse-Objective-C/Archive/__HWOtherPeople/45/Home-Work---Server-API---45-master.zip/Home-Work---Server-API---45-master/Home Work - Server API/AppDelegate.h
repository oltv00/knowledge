//
//  AppDelegate.h
//  Home Work - Server API
//
//  Created by Roman Bogomolov on 12/10/14.
//  Copyright (c) 2014 Roman Bogomolov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

