//
//  RBDetailViewController.h
//  Home Work - Server API
//
//  Created by Roman Bogomolov on 13/10/14.
//  Copyright (c) 2014 Roman Bogomolov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RBDetailViewController : UITableViewController

@property (strong, nonatomic) NSString* userID;


@end
