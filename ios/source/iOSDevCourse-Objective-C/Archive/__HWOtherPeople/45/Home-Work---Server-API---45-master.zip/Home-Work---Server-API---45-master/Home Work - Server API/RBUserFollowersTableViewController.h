//
//  RBUserFollowersTableViewController.h
//  Home Work - Server API
//
//  Created by Roman Bogomolov on 15/10/14.
//  Copyright (c) 2014 Roman Bogomolov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RBUserFollowersTableViewController : UITableViewController

@property (assign, nonatomic) NSString* userID;
@property (assign, nonatomic) BOOL getCase;

@end
