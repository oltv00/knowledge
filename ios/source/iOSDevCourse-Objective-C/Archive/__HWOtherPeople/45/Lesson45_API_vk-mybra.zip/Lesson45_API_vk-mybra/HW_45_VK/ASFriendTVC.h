//
//  ASFriendTVC.h
//  HW_45_VK
//
//  Created by MD on 31.08.15.
//  Copyright (c) 2015 MD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASFriendTVC : UITableViewController <UITableViewDataSource,UITableViewDelegate ,UIScrollViewDelegate>

@end
