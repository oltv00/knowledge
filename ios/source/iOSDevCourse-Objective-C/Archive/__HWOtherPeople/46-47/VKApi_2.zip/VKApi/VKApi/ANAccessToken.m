//
//  ANAccessToken.m
//  VKApi
//
//  Created by Андрей on 31.10.15.
//  Copyright (c) 2015 Андрей. All rights reserved.
//

#import "ANAccessToken.h"

@implementation ANAccessToken

@end
