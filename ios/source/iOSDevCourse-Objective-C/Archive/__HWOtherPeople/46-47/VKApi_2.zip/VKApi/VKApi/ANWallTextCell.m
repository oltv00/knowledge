//
//  ANWallTextCell.m
//  VKApi
//
//  Created by Андрей on 03.11.15.
//  Copyright (c) 2015 Андрей. All rights reserved.
//

#import "ANWallTextCell.h"

@implementation ANWallTextCell




@end
