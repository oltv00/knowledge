//
//  TTAccessToken.m
//  ClientServerAPIs
//
//  Created by Sergey Reshetnyak on 6/3/14.
//  Copyright (c) 2014 sergey. All rights reserved.
//

#import "TTAccessToken.h"

@implementation TTAccessToken

@end
