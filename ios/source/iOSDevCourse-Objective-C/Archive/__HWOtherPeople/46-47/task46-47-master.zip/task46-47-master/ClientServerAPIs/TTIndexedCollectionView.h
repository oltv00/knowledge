//
//  TTIndexedCollectionView.h
//  ClientServerAPIs
//
//  Created by Sergey Reshetnyak on 6/8/14.
//  Copyright (c) 2014 sergey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTIndexedCollectionView : UICollectionView

@property (nonatomic, assign) NSInteger index;

@end
