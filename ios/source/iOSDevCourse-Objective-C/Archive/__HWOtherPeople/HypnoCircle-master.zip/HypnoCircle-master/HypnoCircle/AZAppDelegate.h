//
//  AZAppDelegate.h
//  HypnoCircle
//
//  Created by Alex Alexandrov on 28.12.13.
//  Copyright (c) 2013 Alex Zbirnik. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AZAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
