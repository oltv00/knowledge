create hypno circle for ios 7
