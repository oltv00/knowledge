pixelArt drawing for ios 7 ipad

