//
//  ASObject.h
//  ArraysTest
//
//  Created by Oleksii Skutarenko on 08.10.13.
//  Copyright (c) 2013 Alex Skutarenko. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASObject : NSObject

@property (strong, nonatomic) NSString* name;


- (void) action;

@end
