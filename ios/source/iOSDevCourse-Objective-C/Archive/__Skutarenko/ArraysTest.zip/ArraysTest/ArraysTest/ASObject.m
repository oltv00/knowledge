//
//  ASObject.m
//  ArraysTest
//
//  Created by Oleksii Skutarenko on 08.10.13.
//  Copyright (c) 2013 Alex Skutarenko. All rights reserved.
//

#import "ASObject.h"

@implementation ASObject


- (void) action {
    NSLog(@"%@ ACTION!!!", self.name);
}

@end
