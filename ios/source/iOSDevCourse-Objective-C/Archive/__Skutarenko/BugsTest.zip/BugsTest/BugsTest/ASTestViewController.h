//
//  ASTestViewController.h
//  BugsTest
//
//  Created by Oleksii Skutarenko on 04.04.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^TestBlock)(void);


@interface ASTestViewController : UIViewController

@property (copy, nonatomic) TestBlock block;

- (void) testMethod;

@end
