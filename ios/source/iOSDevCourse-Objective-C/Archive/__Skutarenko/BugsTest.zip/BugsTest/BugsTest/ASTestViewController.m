//
//  ASTestViewController.m
//  BugsTest
//
//  Created by Oleksii Skutarenko on 04.04.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import "ASTestViewController.h"

@interface ASTestViewController ()

@end

@implementation ASTestViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    CGRect r = self.view.bounds;
    r.origin = CGPointZero;
    
    UIImageView* imageView = [[UIImageView alloc] initWithFrame:r];
    imageView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
    NSString* filePath = [[NSBundle mainBundle] pathForResource:@"image" ofType:@"png"];
    
    imageView.image = [UIImage imageWithContentsOfFile:filePath];
    
    [self.view addSubview:imageView];
    
    //[self testMethod];
    
    //CGMutablePathRef path = CGPathCreateMutable();
    //CGPathAddEllipseInRect(path, &CGAffineTransformIdentity, CGRectZero);
    //CGPathRelease(path);
    
    //__weak ASTestViewController* weakSelf = self;
    
    /*
    [[NSNotificationCenter defaultCenter] addObserverForName:@"TestNotification"
                                                      object:nil
                                                       queue:[NSOperationQueue mainQueue]
                                                  usingBlock:^(NSNotification *note) {
                                                      [self testMethod];
                                                  }];
    */
    
    /*
    [self testMethod];
    
    [self testMethod];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"a");
    });
    
    NSLog(@"b");
     */
}

- (void) testMethod {
    NSLog(@"testMethod");
}

- (void) dealloc {
    NSLog(@"ASTestViewController deallocated");
}

@end
