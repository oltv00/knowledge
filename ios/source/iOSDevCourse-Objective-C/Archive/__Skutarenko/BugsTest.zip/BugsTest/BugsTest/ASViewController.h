//
//  ASViewController.h
//  BugsTest
//
//  Created by Oleksii Skutarenko on 04.04.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASViewController : UIViewController

- (IBAction) actionTest:(id)sender;

@end
