//
//  ASViewController.m
//  BugsTest
//
//  Created by Oleksii Skutarenko on 04.04.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import "ASViewController.h"
#import "ASTestViewController.h"

@interface ASViewController () <UIPopoverControllerDelegate>

@property (strong, nonatomic) UIPopoverController* popover;

@property (assign, nonatomic) id shmelegate;

@end

@implementation ASViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    //[[NSArray arrayWithObjects:@"a", @"b", nil] objectAtIndex:5];
    
    //[self performSelector:@selector(abc)];
}

#pragma mark - Actions

- (IBAction) actionTest:(UIButton*)sender {
    
    ASTestViewController* vc = [[ASTestViewController alloc] init];
    
    UIPopoverController* popover = [[UIPopoverController alloc] initWithContentViewController:vc];
    [popover setPopoverContentSize:CGSizeMake(300, 400)];
    popover.delegate = self;
    
    [popover presentPopoverFromRect:sender.bounds
                             inView:sender
           permittedArrowDirections:UIPopoverArrowDirectionAny
                           animated:YES];
    
    /*
    vc.block = ^{
        [vc testMethod];
    };*/
    
    self.popover = popover;

    self.shmelegate = popover;
    
}

#pragma mark - UIPopoverControllerDelegate

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
    
    self.popover = nil;
    
    /*
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.shmelegate dismissPopoverAnimated:YES];
    });
     */
}

@end
