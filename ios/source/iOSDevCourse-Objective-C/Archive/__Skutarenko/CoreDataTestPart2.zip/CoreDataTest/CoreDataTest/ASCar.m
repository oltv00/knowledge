//
//  ASCar.m
//  CoreDataTest
//
//  Created by Oleksii Skutarenko on 01.02.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import "ASCar.h"
#import "ASStudent.h"


@implementation ASCar

@dynamic model;
@dynamic owner;

@end
