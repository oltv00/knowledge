//
//  ASCourse.m
//  CoreDataTest
//
//  Created by Oleksii Skutarenko on 01.02.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import "ASCourse.h"
#import "ASStudent.h"
#import "ASUniversity.h"


@implementation ASCourse

@dynamic name;
@dynamic university;
@dynamic students;

@end
