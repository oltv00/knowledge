//
//  ASStudent.m
//  CoreDataTest
//
//  Created by Oleksii Skutarenko on 01.02.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import "ASStudent.h"
#import "ASCar.h"
#import "ASCourse.h"
#import "ASUniversity.h"


@implementation ASStudent

@dynamic dateOfBirth;
@dynamic firstName;
@dynamic lastName;
@dynamic score;
@dynamic car;
@dynamic university;
@dynamic courses;

@end
