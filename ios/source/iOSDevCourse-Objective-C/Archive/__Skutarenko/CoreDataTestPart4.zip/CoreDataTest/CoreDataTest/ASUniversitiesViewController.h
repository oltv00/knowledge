//
//  ASUniversityViewController.h
//  CoreDataTest
//
//  Created by Oleksii Skutarenko on 13.02.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASCoreDataViewController.h"

@interface ASUniversitiesViewController : ASCoreDataViewController



@end
