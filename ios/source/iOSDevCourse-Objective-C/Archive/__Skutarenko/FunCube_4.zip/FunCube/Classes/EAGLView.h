//
//  EAGLView.h
//  FunCube
//
//  Created by Алексей on 8/27/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>
#import "OpenGLCommon.h"
@class MySlider;
@class MyCube;
/*
This class wraps the CAEAGLLayer from CoreAnimation into a convenient UIView subclass.
The view content is basically an EAGL surface you render your OpenGL scene into.
Note that setting the view non-opaque will only work if the EAGL surface has an alpha channel.
*/
@interface EAGLView : UIView {
    
@private
    /* The pixel dimensions of the backbuffer */
    GLint backingWidth;
    GLint backingHeight;
    
    EAGLContext *context;
    
    /* OpenGL names for the renderbuffer and framebuffers used to render to this view */
    GLuint viewRenderbuffer, viewFramebuffer;
    
    /* OpenGL name for the depth buffer that is attached to viewFramebuffer, if it exists (0 if it does not exist) */
    GLuint depthRenderbuffer;
    
    NSTimer *animationTimer;
    NSTimeInterval animationInterval;
	
	//// UILabel
	UILabel	*headerLabel;
	
	//// UIImageView touches
	MySlider *horisontalRotating;
	MySlider *verticalRotating;
	MySlider *circleRotating;
	
	//// testing cube
	MyCube *cube;
	
	
	GLuint textures[7];
}
@property NSTimeInterval animationInterval;
@property (nonatomic,retain) MySlider *horisontalRotating;
@property (nonatomic,retain) MySlider *verticalRotating;
@property (nonatomic,retain) MySlider *circleRotating;
@property (nonatomic,retain) UILabel  *headerLabel;
@property (nonatomic,retain) MyCube   *cube;

- (void)startAnimation;
- (void)stopAnimation;
- (void)drawView;

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event;

- (void)loadTexture:(NSString *)name intoLocation:(GLuint)location;




@end
