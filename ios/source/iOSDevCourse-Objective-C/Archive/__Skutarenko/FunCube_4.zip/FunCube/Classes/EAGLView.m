//
//  EAGLView.m
//  FunCube
//
//  Created by Алексей on 8/27/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//



#import <QuartzCore/QuartzCore.h>
#import <OpenGLES/EAGLDrawable.h>
#import "EAGLView.h"
#import "MySlider.h"
#import "CubePart.h"
#import "MyCube.h"
#import "OpenGLCommon.h"
#import "CubeBody.h"

#define USE_DEPTH_BUFFER 1
#define DEGREES_TO_RADIANS(__ANGLE) ((__ANGLE) / 180.0 * M_PI)

// A class extension to declare private methods
@interface EAGLView ()

@property (nonatomic, retain) EAGLContext *context;
@property (nonatomic, assign) NSTimer *animationTimer;

- (BOOL) createFramebuffer;
- (void) destroyFramebuffer;

@end


@implementation EAGLView

@synthesize context;
@synthesize animationTimer;
@synthesize animationInterval;
@synthesize horisontalRotating,verticalRotating,circleRotating;
@synthesize headerLabel;
@synthesize cube;

// You must implement this method
+ (Class)layerClass {
    return [CAEAGLLayer class];
}


//The GL view is stored in the nib file. When it's unarchived it's sent -initWithCoder:
- (id)initWithCoder:(NSCoder*)coder {
    
    if ((self = [super initWithCoder:coder])) {
        // Get the layer
        CAEAGLLayer *eaglLayer = (CAEAGLLayer *)self.layer;
        
        eaglLayer.opaque = YES;
        eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
                                        [NSNumber numberWithBool:NO], kEAGLDrawablePropertyRetainedBacking, kEAGLColorFormatRGBA8, kEAGLDrawablePropertyColorFormat, nil];
        
        context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
        
        if (!context || ![EAGLContext setCurrentContext:context]) {
            [self release];
            return nil;
        }
        
        animationInterval = 1.0 / 60.0;
    }
	
	
	const GLfloat zNear = 0.1, zFar = 1000.0, fieldOfView = 60; //60
    GLfloat size;
	
    glEnable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);
    size = zNear * tanf(DEGREES_TO_RADIANS(fieldOfView) / 2.0);
	
	// This give us the size of the iPhone display
    CGRect rect = self.bounds;
    glFrustumf(-size, size, -size / (rect.size.width / rect.size.height), size / (rect.size.width / rect.size.height), zNear, zFar);
    glViewport(0, 0, rect.size.width, rect.size.height);
	
	glClearColor(0.2f, 0.3f, 0.5f, 0.0f);
	glMatrixMode(GL_MODELVIEW); 
	glEnable(GL_TEXTURE_2D);
	

	

	horisontalRotating	= [[MySlider alloc]initWithFrame:CGRectMake(0,440,280,40)];
	verticalRotating	= [[MySlider alloc]initWithFrame:CGRectMake(280,155,40,285)];
	circleRotating		= [[MySlider alloc]initWithFrame:CGRectMake(0,100,280,55)];

	horisontalRotating.image= [UIImage imageNamed:@"yRotation.png"];
	verticalRotating.image	= [UIImage imageNamed:@"xRotation.png"];
	circleRotating.image	= [UIImage imageNamed:@"zRotation.png"];

	
	[self addSubview:horisontalRotating];
	[self addSubview:verticalRotating];
	[self addSubview:circleRotating];	
	
	headerLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,20,320,80)];
	headerLabel.text	= [NSString stringWithString:@"My Cube"];
	headerLabel.textColor = [UIColor redColor];
	headerLabel.textAlignment = UITextAlignmentCenter;
//	headerLabel.font	=	[headerLabel.font fontWithSize:50];
	headerLabel.font	=	[UIFont boldSystemFontOfSize:60];
	headerLabel.backgroundColor = [UIColor colorWithRed:1 green:1 blue:1 alpha:0];
	[self addSubview:headerLabel];
	
	glGenTextures(7, textures);
	[self loadTexture:@"black.png" intoLocation:textures[0]];
	[self loadTexture:@"red.png" intoLocation:textures[1]];
	[self loadTexture:@"green.png" intoLocation:textures[2]];
	[self loadTexture:@"yellow.png" intoLocation:textures[3]];
	[self loadTexture:@"blue.png" intoLocation:textures[4]];
	[self loadTexture:@"white.png" intoLocation:textures[5]];
	[self loadTexture:@"brown.png" intoLocation:textures[6]];
	
	cube = [[MyCube alloc]initWithPosition:Vector3DMake(-0.25,-0.65,-4) Size:2.1]; 
	
    return self;
}


- (void)drawView {
 
    [EAGLContext setCurrentContext:context];
    glBindFramebufferOES(GL_FRAMEBUFFER_OES, viewFramebuffer);
    glViewport(0, 0, backingWidth, backingHeight);
	
	const GLfloat textureCoords[]= {
		0, 1,
		0, 0,
		1, 0,
		1, 1

	};

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	if (cube.isAnimated) [cube animation];
	
	
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	
	for (CubePart *newPart in cube.parts) {
		for (int i=0;i<6;i++) {
			glBindTexture(GL_TEXTURE_2D, textures[newPart.textures[i]]);
		
			Vector3D *vertexes = malloc(4*sizeof(Vector3D));	
			for (int j=0;j<4;j++)
			{	vertexes[j] = newPart.vertices[verticesOfSides[i*4+j]];
			}
			glVertexPointer(3, GL_FLOAT, 0,vertexes);
			glTexCoordPointer(2, GL_FLOAT, 0,textureCoords);
			glPushMatrix();
			{
				glTranslatef(cube.position.x, cube.position.y, cube.position.z);
				glDrawArrays(GL_TRIANGLE_FAN, 0,4);
			}
			glPopMatrix();
			free(vertexes);
		}
	}

	
	
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer);
    [context presentRenderbuffer:GL_RENDERBUFFER_OES];
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	
	UITouch *touch = [[event allTouches]anyObject];
	CGPoint location = [touch locationInView:self];
		
	if (CGRectContainsPoint(horisontalRotating.frame,location))
		{	[horisontalRotating addPoint:&location];
		}
	else
	if (CGRectContainsPoint(verticalRotating.frame,location))
		{	[verticalRotating addPoint:&location];
		}
	else
	if (CGRectContainsPoint(circleRotating.frame,location))
		{	[circleRotating addPoint:&location];
		}	
	else if (!cube.isAnimated) {
		CGPoint selectedElement = [cube getSelectedElement:location];
		selectedElement = CGPointMake(0,0);  // for deleting warning )))
	}	
	
	
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
	UITouch *touch = [[event allTouches]anyObject];
	CGPoint location = [touch locationInView:self];
	
	if (CGRectContainsPoint(horisontalRotating.frame,location))
	{	[horisontalRotating addPoint:&location];
		[cube cubeRotation:-DEGREES_TO_RADIANS([horisontalRotating getSpeedX]) Normal:Vector3DMake(0,1,0)];
	}
	else if (CGRectContainsPoint(verticalRotating.frame,location))
	{	[verticalRotating addPoint:&location];
		[cube cubeRotation:-DEGREES_TO_RADIANS([verticalRotating getSpeedY])Normal:Vector3DMake(1,0,0)];
	} 
	else if (CGRectContainsPoint(circleRotating.frame,location))
	{	[circleRotating addPoint:&location];
		[cube cubeRotation:DEGREES_TO_RADIANS([circleRotating getSpeedX])Normal:Vector3DMake(0,0,1)];
	} 
	else 
	{//	[self touchesEnded:touches withEvent:event];
		[horisontalRotating reset];
		[verticalRotating reset];
		[circleRotating reset];
		if (!cube.isAnimated)
		{	CGPoint selectedElement = [cube getSelectedElement:location];
			selectedElement = CGPointMake(0,0);  // for deleting warning )))
		}
	}	
}	


- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
	[horisontalRotating reset];
	[verticalRotating reset];
	[circleRotating reset];
	[cube resetSelections];
}


- (void)loadTexture:(NSString *)name intoLocation:(GLuint)location {
	
	CGImageRef textureImage = [UIImage imageNamed:name].CGImage;
	if (textureImage == nil) {
        NSLog(@"Failed to load texture image");
		return;
    }
	
    NSInteger texWidth = CGImageGetWidth(textureImage);
    NSInteger texHeight = CGImageGetHeight(textureImage);
	
	GLubyte *textureData = (GLubyte *)malloc(texWidth * texHeight * 4);
	
    CGContextRef textureContext = CGBitmapContextCreate(textureData,
														texWidth, texHeight,
														8, texWidth * 4,
														CGImageGetColorSpace(textureImage),
														kCGImageAlphaPremultipliedLast);
	
	// Rotate the image
	CGContextTranslateCTM(textureContext, 0, texHeight);
	CGContextScaleCTM(textureContext, 1.0, -1.0);
	
	CGContextDrawImage(textureContext, CGRectMake(0.0, 0.0, (float)texWidth, (float)texHeight), textureImage);
	CGContextRelease(textureContext);
	
	glBindTexture(GL_TEXTURE_2D, location);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, texWidth, texHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData);
	
	free(textureData);
	
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
}


- (void)layoutSubviews {
    [EAGLContext setCurrentContext:context];
    [self destroyFramebuffer];
    [self createFramebuffer];
    [self drawView];
}
- (BOOL)createFramebuffer {
    
    glGenFramebuffersOES(1, &viewFramebuffer);
    glGenRenderbuffersOES(1, &viewRenderbuffer);
    
    glBindFramebufferOES(GL_FRAMEBUFFER_OES, viewFramebuffer);
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer);
    [context renderbufferStorage:GL_RENDERBUFFER_OES fromDrawable:(CAEAGLLayer*)self.layer];
    glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER_OES, viewRenderbuffer);
    
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES, &backingWidth);
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &backingHeight);
    
    if (USE_DEPTH_BUFFER) {
        glGenRenderbuffersOES(1, &depthRenderbuffer);
        glBindRenderbufferOES(GL_RENDERBUFFER_OES, depthRenderbuffer);
        glRenderbufferStorageOES(GL_RENDERBUFFER_OES, GL_DEPTH_COMPONENT16_OES, backingWidth, backingHeight);
        glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_DEPTH_ATTACHMENT_OES, GL_RENDERBUFFER_OES, depthRenderbuffer);
    }
    
    if(glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) != GL_FRAMEBUFFER_COMPLETE_OES) {
        NSLog(@"failed to make complete framebuffer object %x", glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES));
        return NO;
    }
    
    return YES;
}
- (void)destroyFramebuffer {
    
    glDeleteFramebuffersOES(1, &viewFramebuffer);
    viewFramebuffer = 0;
    glDeleteRenderbuffersOES(1, &viewRenderbuffer);
    viewRenderbuffer = 0;
    
    if(depthRenderbuffer) {
        glDeleteRenderbuffersOES(1, &depthRenderbuffer);
        depthRenderbuffer = 0;
    }
}
- (void)startAnimation {
    self.animationTimer = [NSTimer scheduledTimerWithTimeInterval:animationInterval target:self selector:@selector(drawView) userInfo:nil repeats:YES];
}
- (void)stopAnimation {
    self.animationTimer = nil;
}
- (void)setAnimationTimer:(NSTimer *)newTimer {
    [animationTimer invalidate];
    animationTimer = newTimer;
}
- (void)setAnimationInterval:(NSTimeInterval)interval {
    
    animationInterval = interval;
    if (animationTimer) {
        [self stopAnimation];
        [self startAnimation];
    }
}


- (void)dealloc {
    
    [self stopAnimation];
    
    if ([EAGLContext currentContext] == context) {
        [EAGLContext setCurrentContext:nil];
    }
	[cube release];
	[headerLabel release];
	[circleRotating release];
	[verticalRotating release];
	[horisontalRotating release];
    [context release];  
    [super dealloc];
}

@end
