//
//  MySlider.h
//  FunCube
//
//  Created by Алексей on 8/31/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MySlider : UIImageView {
	
@private
	CGPoint first;
	CGPoint second;
}

-(void) addPoint:(CGPoint *) point;
-(void) reset;
-(float) getSpeedX;
-(float) getSpeedY;

@end
