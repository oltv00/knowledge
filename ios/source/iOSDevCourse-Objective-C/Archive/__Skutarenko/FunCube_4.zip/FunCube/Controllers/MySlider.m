//
//  MySlider.m
//  FunCube
//
//  Created by Алексей on 8/31/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "MySlider.h"


@implementation MySlider

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code

		first	= CGPointMake(0,0);
		second	= CGPointMake(0,0);
    }
    return self;
}

-(void) addPoint:(CGPoint *) point {
	first = second;
	second.x = point->x;
	second.y = point->y;
}	

-(void) reset {
	first	= CGPointMake(0,0);
	second	= CGPointMake(0,0);
}

-(float) getSpeedX {
	return second.x-first.x;
}
-(float) getSpeedY {
	return second.y-first.y;
}



- (void)dealloc {
    [super dealloc];
}


@end
