//
//  CubeBody.h
//  FunCube
//
//  Created by Алексей on 9/2/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OpenGLCommon.h"

static const GLuint verticesOfSides[24] = {
	0,1,2,3, //vertices of top
	4,0,3,7, //vertices of back
	5,4,7,6, //vertices of bottom
	1,5,6,2, //vertices of front
	4,5,1,0, //vertices of left 
	3,2,6,7  //vertices of right
};



static const GLuint sidesOfVertices[24] = {
	0,1,4,	 //sides of 1 
	0,3,4,	 //sides of 2	
	0,3,5,	 //sides of 3
	0,1,5,	 //sides of 4
	1,2,4,	 //sides of 5
	2,3,4,	 //sides of 6
	2,3,5,	 //sides of 7
	1,2,5	 //sides of 8
};



typedef enum {
	top = 0,
	back,
	bottom,
	front,
	left,
	right
} SideType;

@interface CubeBody : NSObject {

	Vector3D*	vertices;	
	
}
@property (nonatomic,readonly) Vector3D *vertices;

- (id) initWithPosition:(Vector3D)vector Size:(GLfloat)size;
- (void) rotation:(GLfloat)angle Normal:(Vector3D)_normal;
@end
