//
//  CubeBody.m
//  FunCube
//
//  Created by Алексей on 9/2/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "CubeBody.h"


@implementation CubeBody
@synthesize vertices; 

- (id) initWithPosition:(Vector3D)vector Size:(GLfloat)size
{
	self = [super init];
	if (self != nil) {
		
		size /=2; 
		vertices	= malloc(11*sizeof(Vector3D));
		vertices[0] = Vector3DMake(vector.x-size, vector.y+size, vector.z+size);
		vertices[1] = Vector3DMake(vector.x-size, vector.y-size, vector.z+size);
		vertices[2] = Vector3DMake(vector.x+size, vector.y-size, vector.z+size);
		vertices[3] = Vector3DMake(vector.x+size, vector.y+size, vector.z+size);
		vertices[4] = Vector3DMake(vector.x-size, vector.y+size, vector.z-size);
		vertices[5] = Vector3DMake(vector.x-size, vector.y-size, vector.z-size);
		vertices[6] = Vector3DMake(vector.x+size, vector.y-size, vector.z-size);
		vertices[7] = Vector3DMake(vector.x+size, vector.y+size, vector.z-size);
	}	
	return self;
}			

- (void) rotation:(GLfloat)angle Normal:(Vector3D)_normal {
	for (int i =0;i<8;i++)
		vertices[i] = rotation3D(vertices[i],_normal,angle);
}


- (void) dealloc
{	
	free(vertices);
	[super dealloc];
}
	
@end
