//
//  CubePart.h
//  FunCube
//
//  Created by Алексей on 8/31/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OpenGLES/ES1/glext.h>
#import "OpenGLCommon.h"
#import "CubeBody.h"

typedef enum {
	black = 0,
	red,
	green,
	yellow,
	blue,
	white,
	brown
} TextureType;


@interface CubePart : CubeBody {
	
@public
	GLfloat		rotationAngle;
	Vector3D	rotationVector;
	GLuint		*textures;
}


@property (readonly) GLfloat rotationAngle;
@property (readonly) Vector3D rotationVector;
@property (nonatomic,readonly) GLuint	*textures;

- (id) initWithPosition:(Vector3D)vector Size:(GLfloat)size;
- (void) addSideTextureType:(GLuint)type Side:(GLuint)stype;
- (void) setRotationAngle:(GLfloat)angle Vector:(Vector3D)vector;

@end
