//
//  CubePart.m
//  FunCube
//
//  Created by Алексей on 8/31/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "CubePart.h"

@implementation CubePart
@synthesize rotationAngle,rotationVector;
@synthesize textures;

- (id) initWithPosition:(Vector3D)vector Size:(GLfloat)size
{
	self = [super initWithPosition:vector Size:size];
	if (self != nil) {
		
		textures = malloc(6*sizeof(GLuint));
		for (int i=0;i<6;i++)
		{	textures[i] = black;
		}
			
		rotationAngle	= 0;
		rotationVector	= Vector3DMake(0,0,0);
	}
	return self;
}

- (void) addSideTextureType:(GLuint)type Side:(GLuint)stype {
		textures[stype] = type;
}


-(void) setRotationAngle:(GLfloat)angle Vector:(Vector3D)vector {
	rotationAngle = angle;
	rotationVector = vector;
}


- (void) dealloc
{	
	free(textures);
	[super dealloc];
}



@end
