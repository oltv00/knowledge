//
//  MyCube.h
//  FunCube
//
//  Created by Алексей on 8/31/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OpenGLCommon.h"
#import "CubeBody.h"

typedef enum {
	rotationX=1,
	rotationY,
	rotationZ
} DirectionType;

@interface MyCube : CubeBody {
	
@private
	Vector3D	*normals;
	GLint		animationDirection;
	Vector3D	animationElement;
	GLint		animationCounter;
	
	
@public	
	NSMutableArray *parts;
	GLuint		*partsMap;

	Vector3D	position;
	GLint		selectedElement;
	GLint		selectedSide;
	BOOL		isAnimated;
}
@property (nonatomic,retain) NSMutableArray *parts;
@property (nonatomic,readonly) Vector3D *normals;
@property (readonly) Vector3D	position;
@property (readonly) GLint	selectedElement;
@property (readonly) GLint	selectedSide;
@property (readonly) BOOL	isAnimated;
@property (nonatomic,readonly) GLuint	*partsMap;


- (id) initWithPosition:(Vector3D)vector Size:(GLfloat)size;
- (void) cubeRotation:(GLfloat)angle Normal:(Vector3D)_normal;
- (void) rowRotationElement:(Vector3D)element Direction:(GLuint)direction Angle:(GLfloat)angle;

- (void) transformParts;
- (CGPoint) getSelectedElement:(CGPoint)location;
- (GLint) getSelectedSide:(CGPoint)location Vector1:(Vector3D)p1 Vector2:(Vector3D)p2;
- (BOOL) intersectSideVector:(Vector3D)p1 Vector2:(Vector3D)p2 Side:(GLuint) sideType IntersectPoint:(Vector3D*)point;
- (GLuint) getIntersectQuorterPart:(Triangle3D) t Vector1:(Vector3D)p1 Vector2:(Vector3D)p2;
- (void) resetSelections;
- (void) animation; 
@end
