//
//  MyCube.m
//  FunCube
//
//  Created by Алексей on 8/31/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "MyCube.h"
#import "CubePart.h"
#define ANIMATION_CYCLES 78

@implementation MyCube
@synthesize parts;
@synthesize normals;
@synthesize position;
@synthesize selectedElement, selectedSide;
@synthesize isAnimated;
@synthesize	partsMap;

const GLuint xRow[] = {
	0,  3, 6,
	9, 12, 15,
	18, 21, 24
};

const GLuint yRow[] = {	
	0,  1,  2,
	9, 10, 11,
	18, 19, 20
};	

const GLuint zRow[] = {
	2,  1,  0,
	5,  4,  3,
	8,  7,  6
};


const GLuint xRowStep = 1;
const GLuint yRowStep = 3;
const GLuint zRowStep = 9;


const GLuint elementsOnSides[] = {
	 0,   1,   2,   3,   4,   5,   6,   7,   8,		//top
	18,  19,  20,   9,  10,  11,   0,   1,   2,		//back
	24,  25,  26,  21,  22,  23,  18,  19,  20,		//bottom
	 6,   7,   8,  15,  16,  17,  24,  25,  26,		//front
	18,   9,   0,  21,  12,   3,  24,  15,   6,		//left
	 2,  11,  20,   5,  14,  23,   8,  17,  26		//right
};


- (id) initWithPosition:(Vector3D)vector Size:(GLfloat)size
{
	position = vector;
	vector = Vector3DMake(0,0,0);
	
	self = [super initWithPosition:vector Size:size];
	if (self != nil) {
		
	
		/*		8 vertices and 3 normals of cube
					
				^y
				|
				0		3
			4		7	
							--->x 
				1		2	
			5		6
					  \	
					   \z
						
		*/

		// normals
		normals		= malloc(3*sizeof(Vector3D));
		normals[0]	= Vector3DMake(1,0,0);
		normals[1]  = Vector3DMake(0,1,0);
		normals[2]	= Vector3DMake(0,0,1);
		
		
		
		//selections
		selectedSide	=-1;
		selectedElement =-1;
		
		//animations
		isAnimated		= FALSE;
		animationDirection	= 0;
		animationElement	= Vector3DMake(0,0,0);
		animationCounter	= ANIMATION_CYCLES;   
		
		// map of cubes
		partsMap = malloc(27*sizeof(GLuint));
		for (int i=0; i<27; i++) partsMap[i]=i;
		
		
		//// creating cube partZXY
		size /=3;
		
		// top layer
		CubePart *part000 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x-size,vector.y+size,vector.z+size)	Size:size];
		[part000 addSideTextureType:red	Side:top];
		[part000 addSideTextureType:green	Side:back];
		[part000 addSideTextureType:white	Side:left];
		
		CubePart *part001 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x-size,vector.y,vector.z+size)			Size:size];
		[part001 addSideTextureType:red	Side:top];
		[part001 addSideTextureType:white	Side:left];
		
		CubePart *part002 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x-size,vector.y-size,vector.z+size)	Size:size];
		[part002 addSideTextureType:red	Side:top];
		[part002 addSideTextureType:white	Side:left];
		[part002 addSideTextureType:blue	Side:front];
		
		CubePart *part010 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x,vector.y+size,vector.z+size)			Size:size];
		[part010 addSideTextureType:red	Side:top];
		[part010 addSideTextureType:green	Side:back];
		
		CubePart *part011 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x,vector.y,vector.z+size)				Size:size];
		[part011 addSideTextureType:red	Side:top];

		CubePart *part012 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x,vector.y-size,vector.z+size)			Size:size];
		[part012 addSideTextureType:red	Side:top];
		[part012 addSideTextureType:blue	Side:front];
		
		CubePart *part020 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x+size,vector.y+size,vector.z+size)	Size:size];
		[part020 addSideTextureType:red	Side:top];
		[part020 addSideTextureType:green	Side:back];
		[part020 addSideTextureType:yellow	Side:right];
		
		CubePart *part021 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x+size,vector.y,vector.z+size)			Size:size];
		[part021 addSideTextureType:red	Side:top];
		[part021 addSideTextureType:yellow	Side:right];
		
		CubePart *part022 = [[CubePart alloc]initWithPosition:	
							 Vector3DMake(vector.x+size,vector.y-size,vector.z+size)	Size:size];
		[part022 addSideTextureType:red	Side:top];
		[part022 addSideTextureType:yellow	Side:right];
		[part022 addSideTextureType:blue	Side:front];
		
		// mid layer
		CubePart *part100 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x-size,vector.y+size,vector.z)			Size:size];
		[part100 addSideTextureType:green	Side:back];
		[part100 addSideTextureType:white	Side:left];
		
		CubePart *part101 = [[CubePart alloc]initWithPosition:	
							 Vector3DMake(vector.x-size,vector.y,vector.z)				Size:size];
		[part101 addSideTextureType:white	Side:left];
		
		CubePart *part102 = [[CubePart alloc]initWithPosition:	
							 Vector3DMake(vector.x-size,vector.y-size,vector.z)			Size:size];
		[part102 addSideTextureType:white	Side:left];
		[part102 addSideTextureType:blue	Side:front];
		
		CubePart *part110 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x,vector.y+size,vector.z)				Size:size];
		[part110 addSideTextureType:green	Side:back];
		
		CubePart *part111 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x,vector.y,vector.z)					Size:size];
		
		CubePart *part112 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x,vector.y-size,vector.z)				Size:size];
		[part112 addSideTextureType:blue	Side:front];
		
		CubePart *part120 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x+size,vector.y+size,vector.z)			Size:size];
		[part120 addSideTextureType:green	Side:back];
		[part120 addSideTextureType:yellow	Side:right];
		
		CubePart *part121 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x+size,vector.y,vector.z)				Size:size];
		[part121 addSideTextureType:yellow	Side:right];
		
		CubePart *part122 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x+size,vector.y-size,vector.z)			Size:size];
		[part122 addSideTextureType:yellow	Side:right];
		[part122 addSideTextureType:blue	Side:front];
		
		//	bottom layer
		CubePart *part200 = [[CubePart alloc]initWithPosition:	
							 Vector3DMake(vector.x-size,vector.y+size,vector.z-size)	Size:size];
		[part200 addSideTextureType:brown	Side:bottom];
		[part200 addSideTextureType:green	Side:back];
		[part200 addSideTextureType:white	Side:left];
		
		CubePart *part201 = [[CubePart alloc]initWithPosition:	
							 Vector3DMake(vector.x-size,vector.y,vector.z-size)			Size:size];
		[part201 addSideTextureType:brown	Side:bottom];
		[part201 addSideTextureType:white	Side:left];
		
		CubePart *part202 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x-size,vector.y-size,vector.z-size)	Size:size];
		[part202 addSideTextureType:brown	Side:bottom];
		[part202 addSideTextureType:white	Side:left];
		[part202 addSideTextureType:blue	Side:front];
		
		CubePart *part210 = [[CubePart alloc]initWithPosition:	
							 Vector3DMake(vector.x,vector.y+size,vector.z-size)			Size:size];
		[part210 addSideTextureType:brown	Side:bottom];
		[part210 addSideTextureType:green	Side:back];
		
		CubePart *part211 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x,vector.y,vector.z-size)				Size:size];
		[part211 addSideTextureType:brown	Side:bottom];
		
		CubePart *part212 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x,vector.y-size,vector.z-size)			Size:size];
		[part212 addSideTextureType:brown	Side:bottom];
		[part212 addSideTextureType:blue	Side:front];
		
		CubePart *part220 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x+size,vector.y+size,vector.z-size)	Size:size];
		[part220 addSideTextureType:brown	Side:bottom];
		[part220 addSideTextureType:green	Side:back];
		[part220 addSideTextureType:yellow	Side:right];
		
		CubePart *part221 = [[CubePart alloc]initWithPosition:
							 Vector3DMake(vector.x+size,vector.y,vector.z-size)			Size:size];
		[part221 addSideTextureType:brown	Side:bottom];
		[part221 addSideTextureType:yellow	Side:right];
		
		CubePart *part222 = [[CubePart alloc]initWithPosition:	
							 Vector3DMake(vector.x+size,vector.y-size,vector.z-size)	Size:size];
		[part222 addSideTextureType:brown	Side:bottom];
		[part222 addSideTextureType:yellow	Side:right];
		[part222 addSideTextureType:blue	Side:front];
		
		parts = [[NSMutableArray alloc]init];
		[parts addObject:part000];	[part000 release];
		[parts addObject:part010];	[part010 release];
		[parts addObject:part020];	[part020 release];
		[parts addObject:part001];	[part001 release];
		[parts addObject:part011];	[part011 release];
		[parts addObject:part021];	[part021 release];
		[parts addObject:part002];	[part002 release];
		[parts addObject:part012];	[part012 release];
		[parts addObject:part022];	[part022 release];
		
		[parts addObject:part100];	[part100 release];
		[parts addObject:part110];	[part110 release];
		[parts addObject:part120];	[part120 release];
		[parts addObject:part101];	[part101 release];
		[parts addObject:part111];	[part111 release];
		[parts addObject:part121];	[part121 release];
		[parts addObject:part102];	[part102 release];
		[parts addObject:part112];	[part112 release];
		[parts addObject:part122];	[part122 release];
		
		[parts addObject:part200];	[part200 release];
		[parts addObject:part210];	[part210 release];
		[parts addObject:part220];	[part220 release];
		[parts addObject:part201];	[part201 release];
		[parts addObject:part211];	[part211 release];
		[parts addObject:part221];	[part221 release];
		[parts addObject:part202];	[part202 release];
		[parts addObject:part212];	[part212 release];
		[parts addObject:part222];	[part222 release];
			
	}
	return self;
}

-(void) cubeRotation:(GLfloat)angle Normal:(Vector3D)_normal {
	for (CubePart *part in parts) {
		[part rotation:angle Normal:_normal];
	}
	[self rotation:angle Normal:_normal];
	
	for (int i =0;i<3;i++)
		normals[i] = rotation3D(normals[i],_normal,angle);
}	



-(void) rowRotationElement:(Vector3D)element Direction:(GLuint)direction Angle:(GLfloat)angle {
		
	const GLuint *rowParts;
	GLuint	rowStep = 0; 
	Vector3D _normal;

	switch (direction) {
		case rotationX:	rowStep = (GLuint)element.x*xRowStep;
			rowParts = xRow; _normal = normals[0];		break;
		case rotationY:	rowStep = (GLuint)element.y*yRowStep;
			rowParts = yRow; _normal = normals[1];		break;
		default:	
		case rotationZ:	rowStep = (GLuint)element.z*zRowStep;
			rowParts = zRow; _normal = normals[2];		break;	
	}
	
	for (int i = 0; i<9; i++)
		[[parts objectAtIndex:partsMap[rowParts[i]+rowStep]] rotation:angle Normal:_normal]; 
	
	

}

- (GLint) getSelectedSide:(CGPoint)location Vector1:(Vector3D)p1 Vector2:(Vector3D)p2 {

	
	Vector3D intersectPoint[2];
	GLuint	 intersectSide[2];	
	Vector3D point;
	GLuint	intersectCount = 0;
	GLint	side = -1;
	
	for (int i=0; i<6; i++)
		if ([self intersectSideVector:p1 Vector2:p2 Side:i IntersectPoint:&point])
		{	intersectPoint[intersectCount]	= point;
			intersectSide[intersectCount]	= i;
			intersectCount++;
		}
	if (intersectCount>0)	
	{	if (intersectPoint[0].z > intersectPoint[1].z) side = intersectSide[0];
		if (intersectPoint[0].z <=intersectPoint[1].z) side = intersectSide[1];  
	}	
			
	free(intersectPoint);
	free(intersectSide);
	return side;		
}

- (BOOL) intersectSideVector:(Vector3D)p1 Vector2:(Vector3D)p2 Side:(GLuint) sideType IntersectPoint:(Vector3D*)point
{			
	Vector3D v1 = vertices[verticesOfSides[sideType*4+0]]; v1 = Vector3DAdd(v1,position);
	Vector3D v2 = vertices[verticesOfSides[sideType*4+1]]; v2 = Vector3DAdd(v2,position);
	Vector3D v3 = vertices[verticesOfSides[sideType*4+2]]; v3 = Vector3DAdd(v3,position);
	Vector3D v4 = vertices[verticesOfSides[sideType*4+3]]; v4 = Vector3DAdd(v4,position);
	
	Triangle3D t1 = Triangle3DMake(v1,v2,v3);
	Triangle3D t2 = Triangle3DMake(v1,v3,v4);
	
	if (intersectTriangle(t1,p1,p2,point)) return TRUE;
	if (intersectTriangle(t2,p1,p2,point)) return TRUE;
	return FALSE;
}

- (CGPoint) getSelectedElement:(CGPoint)location {
	
	Vector3D p1,p2;
	calc_select_line(location.x, location.y, &p1, &p2);
	
	GLint side	=-1;
	GLint element = -1;
	
	side = [self getSelectedSide:location Vector1:p1 Vector2:p2];

	if (side < 0) {selectedSide =-1; selectedElement =-1; return CGPointMake(-1,-1);}	
	
	Vector3D v1 = vertices[verticesOfSides[side*4+0]]; v1 = Vector3DAdd(v1,position);
	Vector3D v2 = vertices[verticesOfSides[side*4+1]]; v2 = Vector3DAdd(v2,position);
	Vector3D v3 = vertices[verticesOfSides[side*4+2]]; v3 = Vector3DAdd(v3,position);
	Vector3D v4 = vertices[verticesOfSides[side*4+3]]; v4 = Vector3DAdd(v4,position);
	Vector3D v5 = Vector3DMakeWithStartAndEndPoints(v1,v3);
	v5 = Vector3DAdd(v1,Vector3DMultiply(v5,Vector3DDistance(v1,v3)/2));
	
	Triangle3D t = Triangle3DMake(v1,v2,v3);
	Vector3D point;
	
	GLuint quarterSelected = 0;
	
	//geting number of 0 - 3 part of square
/*	
			v1----------v4
			| \   3   / |
			|   \	/   |
			|  0  x  2  |
			|   /   \   |
			| /   1   \ |
			v2---------v3 
 */ 
	if(intersectTriangle(t, p1, p2, &point))
	{	t = Triangle3DMake(v1,v5,v2);
		if(!intersectTriangle(t, p1, p2, &point))
		{	t = Triangle3DMake(v2,v5,v3);
			quarterSelected = 1;
		}	
	}
	else 
	{	t = Triangle3DMake(v3,v5,v4);
		quarterSelected = 2;
		if(!intersectTriangle(t, p1, p2, &point))
		{	t = Triangle3DMake(v4,v5,v1);
			quarterSelected = 3;
		}	
	}
	
	GLuint partSelected = [self getIntersectQuorterPart:t Vector1:p1 Vector2:p2];
//		getting selected element
	/*	
	 v1----------v4
	 | 0 | 1 | 2 |
	 |---|---|---|
	 | 3 | 4 | 5 |
	 |---|---|---|
	 | 6 | 7 | 8 |
	 v2---------v3 
	 */ 
	switch (quarterSelected) {
		case 0:			
			switch (partSelected) {
				case 0:	element = 0; break;
				case 1: 
				case 2:	element = 3; break;
				case 3: element = 4; break;
				case 4: element = 6; break;	
			}	break;
		case 1:			
			switch (partSelected) {
				case 0:	element = 6; break;
				case 1: 
				case 2:	element = 7; break;
				case 3: element = 4; break;
				case 4: element = 8; break;	
			}	break;	
		case 2:			
			switch (partSelected) {
				case 0:	element = 8; break;
				case 1: 
				case 2:	element = 5; break;
				case 3: element = 4; break;
				case 4: element = 2; break;	
			}	break;	
			
		case 3:			
			switch (partSelected) {
				case 0:	element = 2; break;
				case 1: 
				case 2:	element = 1; break;
				case 3: element = 4; break;
				case 4: element = 0; break;	
			}	break;	
	}
	// begin animation or not
	if (selectedSide<0) 
	{	selectedSide = side;
		selectedElement = element;
	}
	else if (side==selectedSide&&element==selectedElement)  return CGPointMake(side,element);
	else 
	{	//	here animation begins
		isAnimated = TRUE;
		GLuint elementNumber = elementsOnSides[9*selectedSide + selectedElement];
		GLuint elementZ = (GLuint)elementNumber/9;
		GLuint elementY = (elementNumber%9)/3;
		GLuint elementX = (elementNumber%9) - elementY*3;
		animationElement = Vector3DMake (elementX,elementY,elementZ);
		//	we must choose direction of rotating
		// for each side it will be different :((
		if (side == selectedSide)
		{	GLint directionElement = selectedElement - element;
			switch (selectedSide) {
				case 0:		switch (directionElement) {
								case  3:	animationDirection =-rotationX; break;
								case -3:	animationDirection = rotationX; break;	
								case  1:	animationDirection =-rotationY; break;
								case -1:	animationDirection = rotationY; break;
							}	break;
				case 1:		switch (directionElement) {
								case  3:	animationDirection =-rotationX; break;
								case -3:	animationDirection = rotationX; break;	
								case  1:	animationDirection = rotationZ; break;
								case -1:	animationDirection =-rotationZ; break;
							}	break;
				case 2:		switch (directionElement) {
								case  3:	animationDirection =-rotationX; break;
								case -3:	animationDirection = rotationX; break;	
								case  1:	animationDirection = rotationY; break;
								case -1:	animationDirection =-rotationY; break;
							}	break;		
				case 3:		switch (directionElement) {
								case  3:	animationDirection =-rotationX; break;
								case -3:	animationDirection = rotationX; break;	
								case  1:	animationDirection =-rotationZ; break;
								case -1:	animationDirection = rotationZ; break;
							}	break;
				case 4:		switch (directionElement) {
								case  3:	animationDirection =-rotationZ; break;
								case -3:	animationDirection = rotationZ; break;	
								case  1:	animationDirection =-rotationY; break;
								case -1:	animationDirection = rotationY; break;
							}	break;	
				case 5:		switch (directionElement) {
								case  3:	animationDirection = rotationZ; break;
								case -3:	animationDirection =-rotationZ; break;	
								case  1:	animationDirection =-rotationY; break;
								case -1:	animationDirection = rotationY; break;
							}	break;
			}
		}
		else 
		{	switch (selectedSide) {
				case 0:		switch (side) {
								case  1:	animationDirection =-rotationX; break;
								case  3:	animationDirection = rotationX; break;	
								case  4:	animationDirection =-rotationY; break;
								case  5:	animationDirection = rotationY; break;
							}	break;
				case 1:		switch (side) {
								case  2:	animationDirection =-rotationX; break;
								case  0:	animationDirection = rotationX; break;	
								case  4:	animationDirection = rotationZ; break;
								case  5:	animationDirection =-rotationZ; break;
							}	break;
				case 2:		switch (side) {
								case  3:	animationDirection =-rotationX; break;
								case  1:	animationDirection = rotationX; break;	
								case  4:	animationDirection = rotationY; break;
								case  5:	animationDirection =-rotationY; break;
							}	break;		
				case 3:		switch (side) {
								case  0:	animationDirection =-rotationX; break;
								case  2:	animationDirection = rotationX; break;	
								case  4:	animationDirection =-rotationZ; break;
								case  5:	animationDirection = rotationZ; break;
							}	break;
				case 4:		switch (side) {
								case  1:	animationDirection =-rotationZ; break;
								case  3:	animationDirection = rotationZ; break;	
								case  2:	animationDirection =-rotationY; break;
								case  0:	animationDirection = rotationY; break;
							}	break;	
				case 5:		switch (side) {
								case  1:	animationDirection = rotationZ; break;
								case  3:	animationDirection =-rotationZ; break;	
								case  0:	animationDirection =-rotationY; break;
								case  2:	animationDirection = rotationY; break;
							}	break;
			}	
		}	
	}
		
	return CGPointMake(side,element);
}	

- (GLuint) getIntersectQuorterPart:(Triangle3D) t Vector1:(Vector3D)p1 Vector2:(Vector3D)p2 {
	
	//			geting number of 0 - 4 part of quarter
/*				t.v1
				 | 	 \
				 |  0 \	
				 v6---v4	
				 | 1 /|3\____t.v2
				 | / 2| /   
				 v5---v7
				 | 4  /
				 |   /
				 t.v3
*/	
	
	GLuint partSelected = 0;
	Vector3D point;
	
	Vector3D v4 = Vector3DMakeWithStartAndEndPoints(t.v1,t.v2);
	v4 = Vector3DAdd(t.v1,Vector3DMultiply(v4,Vector3DDistance(t.v1,t.v2)*2/3));
	
	Vector3D v5 = Vector3DMakeWithStartAndEndPoints(t.v1,t.v3);
	v5 = Vector3DAdd(t.v1,Vector3DMultiply(v5,Vector3DDistance(t.v1,t.v3)*2/3));
	
	Triangle3D t1 = Triangle3DMake(t.v1,v4,v5);
	
	if(intersectTriangle(t1, p1, p2, &point))
	{	Vector3D v6 = Vector3DMakeWithStartAndEndPoints(t1.v1,t1.v3);
		v6 = Vector3DAdd(t1.v1,Vector3DMultiply(v6,Vector3DDistance(t1.v1,t1.v3)/2)); 
		t1 = Triangle3DMake(t1.v1,v6,t1.v2);
				
		if(!intersectTriangle(t1, p1, p2, &point))
			partSelected = 1;
	}
	else 
	{	Vector3D v7 = Vector3DMakeWithStartAndEndPoints(t.v3,t.v2);
		v7 = Vector3DAdd(t.v3,Vector3DMultiply(v7,Vector3DDistance(t.v3,t.v2)*2/3));
		t1 = Triangle3DMake(t1.v2,v7,t1.v3);
		partSelected = 2;
		
		if(!intersectTriangle(t1, p1, p2, &point))
		{	partSelected = 4;
			t1 = Triangle3DMake(t.v3,t1.v3,t1.v2);
			
			if(!intersectTriangle(t1, p1, p2, &point))
				partSelected = 3;
		}
	}	
	return partSelected;	
}


- (void) animation {
	if (!isAnimated) return;
	
	GLfloat angle = 3.14/2/ANIMATION_CYCLES;

	if (animationCounter == 0)
	{	isAnimated = FALSE;
		animationCounter = ANIMATION_CYCLES; 
		[self transformParts];
		[self resetSelections];
		return;
	}
		
	if (animationDirection<0) 
		[self rowRotationElement:animationElement Direction:-animationDirection Angle: angle];		
	else
		[self rowRotationElement:animationElement Direction: animationDirection Angle:-angle];	
	animationCounter--; 
	
}


- (void) transformParts {
	
	const GLuint *cubes;
	GLuint	delta = 0; 
	BOOL sign = TRUE;
	if (animationDirection < 0) 
	{	sign = FALSE;
		animationDirection = -animationDirection;
	}
	
	
	switch (animationDirection) {
		case rotationX:	delta = (GLuint)animationElement.x*xRowStep;
			cubes = xRow;		break;
		case rotationY:	delta = (GLuint)animationElement.y*yRowStep;
			cubes = yRow;		break;
		default:	
		case rotationZ:	delta = (GLuint)animationElement.z*zRowStep;
			cubes = zRow; 		break;	
	}
	
	GLuint temp;
	if (sign) 
	{	temp = partsMap[cubes[1]+delta];
		partsMap[cubes[1]+delta] = partsMap[cubes[3]+delta];
		partsMap[cubes[3]+delta] = partsMap[cubes[7]+delta];
		partsMap[cubes[7]+delta] = partsMap[cubes[5]+delta];
		partsMap[cubes[5]+delta] = temp;
		
		temp = partsMap[cubes[0]+delta];
		partsMap[cubes[0]+delta] = partsMap[cubes[6]+delta];
		partsMap[cubes[6]+delta] = partsMap[cubes[8]+delta];
		partsMap[cubes[8]+delta] = partsMap[cubes[2]+delta];
		partsMap[cubes[2]+delta] = temp;
	}	
	if (!sign) 
	{	temp = partsMap[cubes[1]+delta];
		partsMap[cubes[1]+delta] = partsMap[cubes[5]+delta];
		partsMap[cubes[5]+delta] = partsMap[cubes[7]+delta];
		partsMap[cubes[7]+delta] = partsMap[cubes[3]+delta];
		partsMap[cubes[3]+delta] = temp;
		
		temp = partsMap[cubes[0]+delta];
		partsMap[cubes[0]+delta] = partsMap[cubes[2]+delta];
		partsMap[cubes[2]+delta] = partsMap[cubes[8]+delta];
		partsMap[cubes[8]+delta] = partsMap[cubes[6]+delta];
		partsMap[cubes[6]+delta] = temp;
	}
}


- (void) resetSelections {
	selectedSide = -1;
	selectedElement = -1;
}	

/*
- (void) calculateShowingSides { 
	GLuint maxVertexes[4];
	maxVertexes[0] = 0;

	for (int i=0; i<7; i++)
		if (vertices[maxVertexes[0]].z<vertices[i+1].z) maxVertexes[0]=i+1;
	
	GLuint equals = 0;
	for (int i=0; i<8; i++)
	//	if (vertices[i].z-vertices[maxVertexes[0]].z<0.6&&vertices[i].z-vertices[maxVertexes[0]].z>-0.6)
		if (vertices[i].z==vertices[maxVertexes[0]].z)
		{	maxVertexes[equals]=i;
			equals++;
		}
	
	if (equals == 1) 
	{	projectionSides[0] = 3;
		for (int i=0; i<3; i++)
			projectionSides[i+1]= sidesOfVertices[maxVertexes[0]*3+i];
	}
	if (equals == 2)
	{	projectionSides[0] = 2;
		for (int i=0,count=1; i<3; i++)
			for (int j=0; j<3; j++)
				if (sidesOfVertices[maxVertexes[0]*3+i] == sidesOfVertices[maxVertexes[1]*3+j])
				{	projectionSides[count] = sidesOfVertices[maxVertexes[0]*3+i];
					count++;	
				}
	}
	////// 
	if (equals == 4)

	{	projectionSides[0] = 1;
		for (int i=0; i<3; i++)
			for (int j=0; j<3; j++)
				if (sidesOfVertices[maxVertexes[0]*3+i] == sidesOfVertices[maxVertexes[1]*3+j])
					for (int n=0; n<3; n++)
						if (sidesOfVertices[maxVertexes[0]*3+i] == sidesOfVertices[maxVertexes[2]*3+n])
						{	projectionSides[1] = sidesOfVertices[maxVertexes[0]*3+i];
							return;
						}
	}	
	
	
}
*/	
- (void) dealloc
{	
	free(partsMap);
	free(normals);
	[parts release];
	[super dealloc];
}

@end
