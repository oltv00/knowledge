//
//  JTBullet.m
//  JustTanks
//
//  Created by Alexander on 30.09.13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "JTBullet.h"
#import "JTGameScene.h"
#import "SimpleAudioEngine.h"
#import "JTObject.h"
#import "JTPlayerTank.h"
#import "JTEnemyTank.h"



@interface JTBullet ()
@property (nonatomic, assign) int damage;
@end

@implementation JTBullet

-(void) animateExplosionWithScale:(float)scale position:(CGPoint)pos {

    [[SimpleAudioEngine sharedEngine] playEffect:@"Explosion1.mp3" pitch:1 pan:0 gain:0.5];
    
    // создаем массив для кадров анимации
    NSMutableArray *animFrames = [NSMutableArray array];
    
    // заполняем массив кадрами
    for(int i = 1; i < 16; i++) {
        CCSpriteFrame *frame = [[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:[NSString stringWithFormat:@"expl_%d.png", i]];
        [animFrames addObject:frame];
    }
    
    // создаем первый спрайт
    CCSprite* expl = [CCSprite spriteWithSpriteFrameName:@"expl_1.png"];
    expl.scale = scale;
    expl.position = pos;
    [self.scene addChild:expl z:55];
    
    // создаем анимацию из массива кадров
    CCAnimation *animation = [CCAnimation animationWithSpriteFrames:animFrames delay:0.05];
    
    // наш первый спрайт выполнит очередь из действий:
    // 1. запустит анимацию
    // 2. вызовет блок, в котором самоуничтожится
    id anim = [CCAnimate actionWithAnimation:animation];
    id cal  = [CCCallBlock actionWithBlock:^{
        [expl removeFromParentAndCleanup:YES];
    }];
    [expl runAction:[CCSequence actions:anim, cal, nil]];
}

-(id) initWithSprite:(CCSprite *)sprite scene:(JTGameScene *)scene properties:(NSDictionary *)props {

    if (self = [super initWithSprite:sprite scene:scene properties:props]) {
        
        [[SimpleAudioEngine sharedEngine] playEffect:@"shot.wav" pitch:1 pan:0 gain:0.5];
        
        _dictance = [[props objectForKey:key_shot_distance] floatValue];
        
        self.rotation = [[props objectForKey:key_rotation] floatValue];
        self.position = [[props objectForKey:key_position] CGPointValue];
        
        _damage = [[props objectForKey:key_damage] floatValue];
        
        float rad = self.rotation * (M_PI / 180);
        
        CGPoint aimPos = ccpAdd(self.position, ccp(sin(rad) * _dictance, cos(rad) * _dictance));
        
        id mov = [CCMoveTo actionWithDuration:0.5 position:aimPos];
        id cal = [CCCallBlock actionWithBlock:^{
            
            // когда пулька достигла конца дистанции, то вызывается взрыв
            [self animateExplosionWithScale:2 position:self.position];

            // и пулька самоуничтожается
            [self removeFromParentAndCleanup:YES];
        }];
        [self runAction:[CCSequence actions:mov, cal, nil]];
    }
    
    return self;
}

-(void) checkForCollisionWithObject:(JTObject*)object {

    CGPoint wPoint = [object convertToWorldSpace:object.sprite.position];
    float width = object.sprite.contentSize.height - 10;
    CGRect rect = CGRectMake(wPoint.x - width/2, wPoint.y - width/2, width, width);
    
    if (CGRectContainsPoint(rect, self.position)) {
        
        object.health -= self.damage;
        
        float percentage = (object.health / (float)object.allHealth) * 100;
        
        ccColor3B color = ccGREEN;
        
        BOOL isDeath = NO;
        
        if (percentage <= 0) {
            //СМЕРТЬ
            isDeath = YES;
            [self animateExplosionWithScale:4 position:object.position];
            
            id del = [CCDelayTime actionWithDuration:0.4];
            id cal = [CCCallBlock actionWithBlock:^{
                
                NSString *name = nil;
                if ([object isKindOfClass:[JTPlayerTank class]]) {
                    name = @"Tank1Crashed.png";
                    
                    self.scene.lives --;
                    [self.scene createPlayer];
                    
                } else if ([object isKindOfClass:[JTEnemyTank class]]) {
                    name = @"Tank2Crashed.png";
                    
                    JTEnemyTank *enemy = (JTEnemyTank*)object;
                    
                    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
                                          [NSNumber numberWithFloat:enemy.shotDistance], key_shot_distance,
                                          [NSNumber numberWithFloat:enemy.damage], key_damage,
                                          [NSNumber numberWithFloat:enemy.allHealth], key_helth,
                                          NSStringFromCGPoint(enemy.startPos), key_position,
                                          [NSNumber numberWithInt:enemy.moveSpeed], key_move_speed,
                                          [NSNumber numberWithInt:enemy.rotSpeed], key_rot_speed,
                                          [NSNumber numberWithInt:enemy.startRotation], key_rotation,
                                          [NSNumber numberWithFloat:enemy.appearingDelay], key_appearing_delay,
                                          nil];
                    
                    id del = [CCDelayTime actionWithDuration:enemy.appearingDelay];
                    id cal = [CCCallBlock actionWithBlock:^{
                        [self.scene createEnemyWithProperties:dict];
                    }];
                    [self.scene runAction:[CCSequence actions:del, cal, nil]];
                    
                    [self.scene.enemiesArray removeObject:object];
                }
                
                if (name) {
                    
                    CCSprite *crashed = [CCSprite spriteWithFile:name];
                    crashed.position = object.position;
                    crashed.rotation = object.rotation;
                    [self.scene addChild:crashed z:50];
                    
                    id fade = [CCFadeOut actionWithDuration:kFadingTime];
                    id cal = [CCCallBlock actionWithBlock:^{
                        [crashed removeFromParentAndCleanup:YES];
                    }];
                    [crashed runAction:[CCSequence actions:fade, cal, nil]];
                }
                
                [object removeFromParentAndCleanup:YES];
            }];
            [self.scene runAction:[CCSequence actions:del, cal, nil]];
        }
        else if (percentage <= 25) color = ccRED;
        else if (percentage <= 50) color = ccYELLOW;
        
        CCProgressTimer *timeBar = [CCProgressTimer progressWithSprite:[CCSprite spriteWithFile:@"circle.png"]];
        timeBar.type = kCCProgressTimerTypeRadial;
        timeBar.reverseDirection = YES;
        timeBar.opacity = 160;
        timeBar.position = object.position;
        timeBar.color = color;
        timeBar.percentage = percentage;
        [self.scene addChild:timeBar z:100];
        
        float time = 4;
        
        id fade = [CCFadeTo actionWithDuration:time  opacity:0];
        id move = [CCMoveBy actionWithDuration:time position:ccp(0, 200)];
        id spawn = [CCSpawn actionOne:fade two:move];
        id cal =  [CCCallBlock actionWithBlock:^{
            [timeBar removeFromParentAndCleanup:YES];
        }];
        [timeBar runAction:[CCSequence actionOne:spawn two:cal]];
        
        if (!isDeath) {
            [self animateExplosionWithScale:2 position:self.position];
        }
        
        [self removeFromParentAndCleanup:YES];
        
    }
}

-(void) update:(float)dt {

    // на протяжении всей жизни пульки (всего полета) постоянно проверяется, не столкнулась ли она с препятствием
    
    // СТОЛКНОВЕНИЕ СО СТЕНАМИ
    // создаем массив для уничтожения стен
    NSMutableArray *deleteArray = [NSMutableArray array];
    
    // извлекаются в цикл поочередно все стены
    for (CCSprite *wall in self.scene.wallsArray) {
        
        // если прямоугольник стены содержит позицию пульки, то ...
        if (CGRectContainsPoint([self.scene getRectFromSprite:wall], self.position)) {
            
            // в массив уничтожения добавляем стену
            [deleteArray addObject:wall];
            // удаляем стену из сцены
            [wall removeFromParentAndCleanup:YES];
            // анимируем взрыв
            [self animateExplosionWithScale:2 position:self.position];
            // удаляем пульку со сцены, чтобы она дальше не летела и не уничтожала все на своем пути
            [self removeFromParentAndCleanup:YES];
        }
    }
    
    // удаляем стены что в массиве удалений из wallsArray
    for (CCSprite *wall in deleteArray) {
        [self.scene.wallsArray removeObject:wall];
    }
    
    // очищаем массив удалений
    [deleteArray removeAllObjects];
    
    
    // СТОЛКНОВЕНИЕ С ТАНКАМИ ВРАГОВ
    for (JTObject *enemy in self.scene.enemiesArray) {
        [self checkForCollisionWithObject:enemy];
    }
    
    // СТОЛКНОВЕНИЕ С ТАНКОМ ИГРОКА
    [self checkForCollisionWithObject:(JTObject*)self.scene.playerTank];
    
}

@end
