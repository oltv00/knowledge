//
//  JTEnemyTank.h
//  JustTanks
//
//  Created by Alexander on 11.10.13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "JTObject.h"

@interface JTEnemyTank : JTObject {
    
}

@property (nonatomic, assign) int damage;
@property (nonatomic, assign) int moveSpeed;
@property (nonatomic, assign) int rotSpeed;
@property (nonatomic, assign) float shotDistance;
@property (nonatomic, assign) float appearingDelay;
@property (nonatomic, assign) CGPoint startPos;
@property (nonatomic, assign) float startRotation;

@end
