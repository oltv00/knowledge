//
//  JTGameScene.m
//  JustTanks
//
//  Created by Alexander on 27.09.13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "JTGameScene.h"
#import "JTPlayerTank.h"
#import "SimpleAudioEngine.h"
#import "JTEnemyTank.h"
#import "JTBonus.h"
#import "JTMainMenuScene.h"


@interface JTGameScene ()
@property (nonatomic, assign) CGSize winSize;
@property (nonatomic, strong) CCSprite *rotLeft;
@property (nonatomic, strong) CCSprite *rotRight;
@property (nonatomic, strong) CCSprite *moveForward;
@property (nonatomic, strong) CCSprite *moveBack;
@property (nonatomic, strong) CCSprite *attack;
@property (nonatomic, assign) ALuint engineEffect;

@property (nonatomic, strong) CCMenu *pauseMenu;
@end


@implementation JTGameScene

+(CCScene *) sceneWithLevel:(int)level
{
	CCScene *scene = [CCScene node];
	
	JTGameScene *layer = [[JTGameScene alloc] initWithLevel:level];
	
	[scene addChild: layer];
	
	return scene;
}

#pragma mark - Init -


-(id) initWithLevel:(int)level
{

	if( (self=[super init]) ) {
		    
        [SimpleAudioEngine sharedEngine].backgroundMusicVolume = 0.3;
        [[SimpleAudioEngine sharedEngine] playBackgroundMusic:@"real_war.mp3" loop:YES];
        
        _wallsArray = [[NSMutableArray alloc] init];
        _enemiesArray = [[NSMutableArray alloc] init];
        
        _winSize = [CCDirector sharedDirector].winSize;
        
        CCLayerColor *lc = [CCLayerColor layerWithColor:ccc4(20, 35, 20, 255)];
        [self addChild:lc];
        
        NSDictionary *root = [[NSDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"Level_%d", level] ofType:@"plist"]];
        
        NSArray *array = [root objectForKey:@"Walls"];
        
        for (NSDictionary *wallDict in array) {
            
            CCSprite *wall = [CCSprite spriteWithFile:@"brickWall.png"];
            wall.position = ccp([[wallDict objectForKey:@"x"] floatValue], [[wallDict objectForKey:@"y"] floatValue]);
            [self addChild:wall];
            
            [_wallsArray addObject:wall];
        }
        
        _lives = max_lives;
        
        [self createPlayer];
        
        NSArray *enemies = [root objectForKey:@"Enemies"];
        
        for (NSDictionary *dict in enemies) {
            
            [self createEnemyWithProperties:dict];
        }
        
        _rotLeft = [self buttonWithName:@"btnRotate.png" pressedName:@"btnRotatePressed.png" pos:ccp(40, 100) flipX:YES flipY:NO];
        _rotRight = [self buttonWithName:@"btnRotate.png" pressedName:@"btnRotatePressed.png" pos:ccp(160, 100) flipX:NO flipY:NO];
        _moveForward = [self buttonWithName:@"btnArrow.png" pressedName:@"btnArrowPressed.png" pos:ccp(100, 150) flipX:NO flipY:NO];
        _moveBack = [self buttonWithName:@"btnArrow.png" pressedName:@"btnArrowPressed.png" pos:ccp(100, 40) flipX:NO flipY:YES];
        _attack = [self buttonWithName:@"btnFire.png" pressedName:@"btnFirePressed.png" pos:ccp(_winSize.width - 80, 100) flipX:NO flipY:NO];

        id del = [CCDelayTime actionWithDuration:[[root objectForKey:@"LevelDuration"] floatValue]];
        id cal = [CCCallBlock actionWithBlock:^{
            [self showBattleResult:@"Winner"];
            
            int level = [[NSUserDefaults standardUserDefaults] integerForKey:key_open_level];
            [[NSUserDefaults standardUserDefaults] setInteger:++level forKey:key_open_level];
        }];
        [self runAction:[CCSequence actions:del, cal, nil]];
        
        
        [self setMenu];
        
        self.isTouchEnabled = YES;
        
	}
	return self;
}

-(void) onEnterTransitionDidFinish {
    [self schedule:@selector(generateBonus) interval:bonus_interval];
}

#pragma mark - Menu -

-(void) setMenu {

    CCMenuItemImage *itemPlay = [CCMenuItemImage itemWithNormalImage:@"bttn_game_play.png" selectedImage:nil block:^(CCMenuItemImage *sender) {
        sender.visible = NO;
        CCMenuItemImage *itemPause = (CCMenuItemImage*)[_pauseMenu getChildByTag:11];
        itemPause.visible = YES;
        [[CCDirector sharedDirector] resume];
    }];
    itemPlay.anchorPoint = ccp(1, 1);
    itemPlay.position = ccp(_winSize.width - 5, _winSize.height - 5);
    itemPlay.tag = 10;
    itemPlay.visible = NO;
    
    CCMenuItemImage *itemPause = [CCMenuItemImage itemWithNormalImage:@"bttn_game_pause.png" selectedImage:nil block:^(CCMenuItemImage *sender) {
        sender.visible = NO;
        CCMenuItemImage *itemPlay = (CCMenuItemImage*)[_pauseMenu getChildByTag:10];
        itemPlay.visible = YES;
        [[CCDirector sharedDirector] pause];
    }];
    itemPause.anchorPoint = ccp(1, 1);
    itemPause.position = ccp(_winSize.width - 5, _winSize.height - 5);
    itemPause.tag = 11;
    
    _pauseMenu = [CCMenu menuWithItems:itemPause, itemPlay, nil];
    _pauseMenu.position = CGPointZero;
    [self addChild:_pauseMenu z:100];
}

#pragma mark - Private Methods -

-(CGRect) getRectFromObject:(JTObject*)object {

    return CGRectMake(object.position.x - object.sprite.contentSize.width/2, object.position.y - object.sprite.contentSize.height/2,
                      object.sprite.contentSize.height, object.sprite.contentSize.height);
}

-(void) generateBonus {

    JTBonusType type = arc4random() % 3;
    
    JTBonus *bonus = [[JTBonus alloc] initWithType:type scene:self];
    
    BOOL didIntersect;
    
    CGRect rect = CGRectZero;
    
    float posX = 0;
    float posY = 0;
    
    do {
       
        didIntersect = NO;
        
        posX = arc4random() % (int) (_winSize.width - bonus.sprite.contentSize.width) + bonus.sprite.contentSize.width/2;
        posY = arc4random() % (int) (_winSize.height - bonus.sprite.contentSize.height) + bonus.sprite.contentSize.height/2;
        
        rect = CGRectMake(posX - bonus.sprite.contentSize.width/2, posY - bonus.sprite.contentSize.height/2,
                          bonus.sprite.contentSize.width, bonus.sprite.contentSize.height);
        
        for (CCSprite *wall in _wallsArray) {
            if (CGRectIntersectsRect([self getRectFromSprite:wall], rect)) {
                didIntersect = YES;
            }
        }
        
        for (JTObject *enemy in _enemiesArray) {
            if (CGRectIntersectsRect([self getRectFromObject:enemy], rect)) {
                didIntersect = YES;
            }
        }
        
        if (CGRectIntersectsRect([self getRectFromObject:_playerTank], rect)) {
            didIntersect = YES;
        }
        
    } while (didIntersect);
    
    bonus.position = ccp(posX, posY);
    [self addChild:bonus z:55];
}

-(void) updateBulletsIcons {

    while ([self getChildByTag:bullet_icon_tag]) {
        [self removeChildByTag:bullet_icon_tag cleanup:YES];
    }
    
    for (int i = 0; i < _playerTank.bullets; i++) {
        
        CCSprite *bullet = [CCSprite spriteWithFile:@"bullet.png"];
        bullet.anchorPoint = ccp(0, 1);
        bullet.position = ccp(5, _winSize.height - 40 - i * 9);
        [self addChild:bullet z:100 tag:bullet_icon_tag];
    }
}

-(void) updateLifeIcons {

    while ([self getChildByTag:life_icon_tag]) {
        [self removeChildByTag:life_icon_tag cleanup:YES];
    }
    
    for (int i = 0; i < _lives; i++) {
        
        CCSprite *life = [CCSprite spriteWithFile:@"Tank1.png"];
        life.scale = 0.35;
        life.position = ccp(15 + i * 20, _winSize.height - 20);
        [self addChild:life z:100 tag:life_icon_tag];
    }
}

-(void) showBattleResult:(NSString*) result {

    CCLabelTTF *gameOverLabel = [CCLabelTTF labelWithString:result fontName:@"Verdana" fontSize:60];
    gameOverLabel.color = ccORANGE;
    gameOverLabel.position = ccp(_winSize.width/2, _winSize.height + 30);
    [self addChild:gameOverLabel z:100];
    
    id move = [CCMoveTo actionWithDuration:2 position:ccp(_winSize.width/2, _winSize.height/2)];
    id bounce = [CCEaseBounceOut actionWithAction:move];
    [gameOverLabel runAction:bounce];
    
    id del = [CCDelayTime actionWithDuration:3];
    id cal = [CCCallBlock actionWithBlock:^{
        [[CCDirector sharedDirector] replaceScene:[CCTransitionPageTurn transitionWithDuration:0.5 scene:[JTMainMenuScene scene]]];
    }];
    [self runAction:[CCSequence actions:del, cal, nil]];
}

-(void) createPlayer {
    
    if (_lives >= 0 ) {
        
        [self updateLifeIcons];
        
        _playerTank = [[JTPlayerTank alloc] initWithSprite:[CCSprite spriteWithFile:@"Tank1.png"] scene:self properties:nil];
        _playerTank.position = ccp(550, 400);
        [self addChild:_playerTank z:50 tag:player_tag ];
        
    } else {
    
        // GAME OVER
        [self showBattleResult:@"Game Over"];
    }
    
    [self updateBulletsIcons];
}

-(void) createEnemyWithProperties:(NSDictionary*)dict {
    
    JTEnemyTank *enemyTank = [[JTEnemyTank alloc] initWithSprite:[CCSprite spriteWithFile:@"Tank2.png"] scene:self properties:dict];
    [self addChild:enemyTank z:50];
    
    [_enemiesArray addObject:enemyTank];
}

-(CCSprite*) buttonWithName:(NSString*)name pressedName:(NSString*)pressedName pos:(CGPoint)pos flipX:(BOOL)flipX flipY:(BOOL)flipY {
    
    CCSprite *sprt = [CCSprite spriteWithFile:name];
    sprt.position = pos;
    sprt.flipX = flipX;
    sprt.flipY = flipY;
    [self addChild:sprt z:100];
    
    CCSprite *sprtPressed = [CCSprite spriteWithFile:pressedName];
    sprtPressed.flipX = flipX;
    sprtPressed.flipY = flipY;
    sprtPressed.anchorPoint = ccp(0, 0);
    sprtPressed.tag = pressed_tag;
    sprtPressed.visible = NO;
    [sprt addChild:sprtPressed];
    
    return sprt;
}

-(CGRect) getRectFromSprite:(CCSprite*)sprt {
    
    return CGRectMake(sprt.position.x - sprt.contentSize.width/2, sprt.position.y - sprt.contentSize.height/2, sprt.contentSize.width, sprt.contentSize.height);
}

-(void) checkForActionInBeginning:(CCSprite*)sprt isDoing:(BOOL*)isDoing location:(CGPoint)location {

    if (CGRectContainsPoint([self getRectFromSprite:sprt], location)) {
        
        CCNode *pressed = [sprt getChildByTag:pressed_tag];
        pressed.visible = YES;
        *isDoing = YES;
        
        _engineEffect = [[SimpleAudioEngine sharedEngine] playEffect:@"engine.wav"];
    }
}

-(void) checkForActionInEnding:(CCSprite*)sprt isDoing:(BOOL*)isDoing location:(CGPoint)location {
  
    CCNode *pressed = [sprt getChildByTag:pressed_tag];
    pressed.visible = NO;
    *isDoing = NO;
    
    [[SimpleAudioEngine sharedEngine] stopEffect:_engineEffect];
}

#pragma mark - Touches -

-(void) registerWithTouchDispatcher
{
	[[[CCDirector sharedDirector] touchDispatcher] addTargetedDelegate:self priority:kCCMenuHandlerPriority swallowsTouches:NO];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event {
    
    CGPoint location = [[CCDirector sharedDirector] convertToGL:[touch locationInView:[touch view]]];
    
    [self checkForActionInBeginning:_rotLeft isDoing:&_isRotatingLeft location:location];
    [self checkForActionInBeginning:_rotRight isDoing:&_isRotatingRight location:location];
    [self checkForActionInBeginning:_moveForward isDoing:&_isMovingForward location:location];
    [self checkForActionInBeginning:_moveBack isDoing:&_isMovingBack location:location];
   
    if (CGRectContainsPoint([self getRectFromSprite:_attack], location)) {
        
        CCNode *pressed = [_attack getChildByTag:pressed_tag];
        pressed.visible = YES;
        
        [_playerTank shoot];
    }
    
    return YES;
}

-(void) ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
	CGPoint location = [[CCDirector sharedDirector] convertToGL:[touch locationInView:[touch view]]];
    
    [self checkForActionInEnding:_rotLeft isDoing:&_isRotatingLeft location:location];
    [self checkForActionInEnding:_rotRight isDoing:&_isRotatingRight location:location];
    [self checkForActionInEnding:_moveForward isDoing:&_isMovingForward location:location];
    [self checkForActionInEnding:_moveBack isDoing:&_isMovingBack location:location];
    
    if (CGRectContainsPoint([self getRectFromSprite:_attack], location)) {
        
        CCNode *pressed = [_attack getChildByTag:pressed_tag];
        pressed.visible = NO;
    }
    
}

@end















