//
//  JTMainMenuScene.h
//  JustTanks
//
//  Created by Alexander on 22.11.13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface JTMainMenuScene : CCLayer {
    
}

+(CCScene *) scene;

@end
