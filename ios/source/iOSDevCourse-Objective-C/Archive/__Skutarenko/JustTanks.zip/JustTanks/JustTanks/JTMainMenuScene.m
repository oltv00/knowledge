//
//  JTMainMenuScene.m
//  JustTanks
//
//  Created by Alexander on 22.11.13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "JTMainMenuScene.h"
#import "JTSelectLevelScene.h"

@implementation JTMainMenuScene

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	
	JTMainMenuScene *layer = [JTMainMenuScene node];
	
	[scene addChild: layer];
	
	return scene;
}

- (id)init
{
    self = [super init];
    if (self) {
        
        CGSize winSize = [CCDirector sharedDirector].winSize;
        
        CCLayerColor *lc = [CCLayerColor layerWithColor:ccc4(227, 207, 113, 255)];
        [self addChild:lc];
        
        CCLabelTTF *label = [CCLabelTTF labelWithString:@"Just Tanks" fontName:@"Avenir" fontSize:100];
        label.position = ccp(winSize.width/2, winSize.height - 130);
        label.color = ccc3(70, 88, 36);
        [self addChild:label];
        
        CCMenuItemImage *itemPlay = [CCMenuItemImage itemWithNormalImage:@"bttn_play.png" selectedImage:@"bttn_play_pressed.png" block:^(id sender) {
            [[CCDirector sharedDirector] replaceScene:[CCTransitionPageTurn transitionWithDuration:0.5 scene:[JTSelectLevelScene scene]]];
        }];
        
        CCMenuItemImage *itemSetting = [CCMenuItemImage itemWithNormalImage:@"bttn_settings.png" selectedImage:@"bttn_settings_pressed.png" block:^(id sender) {
            
        }];
        
        CCMenu *menu = [CCMenu menuWithItems:itemPlay, itemSetting, nil];
        [menu alignItemsVerticallyWithPadding:60];
        [self addChild:menu];
        
    }
    return self;
}

@end
