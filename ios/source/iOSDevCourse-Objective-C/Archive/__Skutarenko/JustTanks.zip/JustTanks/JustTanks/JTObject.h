//
//  JTObject.h
//  JustTanks
//
//  Created by Alexander on 28.09.13.
//
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class JTGameScene;

@interface JTObject : CCNode

@property (nonatomic, strong) CCSprite *sprite;
@property (nonatomic, strong) JTGameScene *scene;
@property (nonatomic, assign) CGSize winSize;
@property (nonatomic, assign) int health;
@property (nonatomic, assign) int allHealth;

-(id) initWithSprite:(CCSprite*)sprite scene:(JTGameScene*)scene properties:(NSDictionary*)props;
-(void) update:(float)dt;
@end
