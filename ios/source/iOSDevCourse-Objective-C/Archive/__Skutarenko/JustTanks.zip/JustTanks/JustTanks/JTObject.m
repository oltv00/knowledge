//
//  JTObject.m
//  JustTanks
//
//  Created by Alexander on 28.09.13.
//
//

#import "JTObject.h"
#import "JTGameScene.h"

@interface JTObject ()

@end

@implementation JTObject

-(id) initWithSprite:(CCSprite*)sprite scene:(JTGameScene*)scene properties:(NSDictionary*)props {

    if (self = [super init]) {
        
        _winSize = [CCDirector sharedDirector].winSize;
        
        _sprite = sprite;
        [self addChild:sprite];
        
        _scene = scene;
        
        [self schedule:@selector(update:)];
        
    }
    
    return self;
}

-(void) update:(float)dt {
    
}

@end
