//
//  JTPlayerTank.h
//  JustTanks
//
//  Created by Alexander on 28.09.13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "JTObject.h"

@interface JTPlayerTank : JTObject {
    
}

@property (nonatomic, assign) int bullets;

-(void) shoot;

@end
