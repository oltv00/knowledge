//
//  ASGroup.h
//  KVCTest
//
//  Created by Oleksii Skutarenko on 25.01.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASGroup : NSObject

@property (strong, nonatomic) NSArray* students;

@end
