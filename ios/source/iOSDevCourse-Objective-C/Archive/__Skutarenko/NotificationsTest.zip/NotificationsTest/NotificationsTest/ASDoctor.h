//
//  ASDoctor.h
//  NotificationsTest
//
//  Created by Oleksii Skutarenko on 21.10.13.
//  Copyright (c) 2013 Alex Skutarenko. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASDoctor : NSObject

@property (assign, nonatomic) CGFloat salary;


@end
