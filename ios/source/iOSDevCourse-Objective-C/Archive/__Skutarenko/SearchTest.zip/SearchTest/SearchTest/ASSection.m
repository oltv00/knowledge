//
//  ASSection.m
//  SearchTest
//
//  Created by Oleksii Skutarenko on 03.01.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import "ASSection.h"

@implementation ASSection

@end
