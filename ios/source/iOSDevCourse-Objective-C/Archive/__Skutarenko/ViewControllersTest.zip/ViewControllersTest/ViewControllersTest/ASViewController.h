//
//  ASViewController.h
//  ViewControllersTest
//
//  Created by Oleksii Skutarenko on 06.11.13.
//  Copyright (c) 2013 Alex Skutarenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASViewController : UIViewController

@end
