//
//  OTPatient.m
//  9_DelegatesHW
//
//  Created by Oleg Tverdokhleb on 02.04.16.
//  Copyright © 2016 Oleg Tverdokhleb. All rights reserved.
//

#import "OTPatient.h"
#import "Data.h"

@implementation OTPatient

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.name = firstNames[arc4random_uniform(51)];
        self.lastName = lastNames[arc4random_uniform(51)];
        self.temperature = 36.6 + ((float)rand() / RAND_MAX) * 4.4;
        self.isPatient = NO;
    }
    return self;
}

- (void)feelsBad {
    [self.delegate patientFeelsBad:self];
}

- (void)howAreYou {
    NSLog(@"Doctor ask question 'How are you? %@ %@'", self.name, self.lastName);
    BOOL isFeelGood = arc4random() % 2;
    if (!isFeelGood) {
        self.isPatient = YES;
        self.temperature = 36.6 + ((float)rand() / RAND_MAX) * 4.4;
        [self.delegate patientFeelsBad:self];
    } else {
        [self shouldRest];
    }
}

- (void)takePill {
    NSLog(@"%@ %@ take a pill", self.name, self.lastName);
}

- (void)makeShot {
    NSLog(@"%@ %@ make a shot", self. name, self.lastName);
}

- (void)shouldRest {
    NSLog(@"Patient %@ %@ should rest", self.name, self.lastName);
    NSLog(@"-------------------------------------------");
}

@end
