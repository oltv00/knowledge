//
//  Course.m
//  HW41-44
//
//  Created by Илья Егоров on 02.08.15.
//  Copyright (c) 2015 Илья Егоров. All rights reserved.
//

#import "Course.h"
#import "Student.h"
#import "Teacher.h"


@implementation Course

@dynamic name;
@dynamic lecturers;
@dynamic students;

@end
