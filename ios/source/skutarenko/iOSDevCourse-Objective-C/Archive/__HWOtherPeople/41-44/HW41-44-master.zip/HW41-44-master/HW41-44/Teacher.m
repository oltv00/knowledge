//
//  Teacher.m
//  HW41-44
//
//  Created by Илья Егоров on 01.08.15.
//  Copyright (c) 2015 Илья Егоров. All rights reserved.
//

#import "Teacher.h"
#import "Course.h"


@implementation Teacher

@dynamic firstName;
@dynamic lastName;
@dynamic courses;

@end
