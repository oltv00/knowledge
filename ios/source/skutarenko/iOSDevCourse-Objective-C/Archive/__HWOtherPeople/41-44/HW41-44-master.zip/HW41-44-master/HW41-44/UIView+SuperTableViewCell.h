//
//  UIView+SuperTableViewCell.h
//  HW41-44
//
//  Created by Илья Егоров on 02.08.15.
//  Copyright (c) 2015 Илья Егоров. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (SuperTableViewCell)

-(UITableViewCell*) superTableViewCell;

@end
