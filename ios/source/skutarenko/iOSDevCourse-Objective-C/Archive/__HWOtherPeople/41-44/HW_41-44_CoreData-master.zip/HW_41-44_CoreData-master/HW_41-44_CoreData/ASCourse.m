//
//  ASCourse.m
//  HW_41-44_CoreData
//
//  Created by MD on 09.08.15.
//  Copyright (c) 2015 MD. All rights reserved.
//

#import "ASCourse.h"
#import "ASStudents.h"
#import "ASTeacher.h"


@implementation ASCourse

@dynamic name;
@dynamic subject;
@dynamic branch;
@dynamic teachers;
@dynamic students;

@end
