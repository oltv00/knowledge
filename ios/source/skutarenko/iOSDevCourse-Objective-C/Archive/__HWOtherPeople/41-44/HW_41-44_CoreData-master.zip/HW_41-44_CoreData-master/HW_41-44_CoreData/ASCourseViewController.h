//
//  ASCourseViewController.h
//  HW_41-44_CoreData
//
//  Created by MD on 09.08.15.
//  Copyright (c) 2015 MD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASCoreDataViewController.h"
#import "ASCourse.h"
#import "ASDataManager.h"

@interface ASCourseViewController : ASCoreDataViewController

@end
