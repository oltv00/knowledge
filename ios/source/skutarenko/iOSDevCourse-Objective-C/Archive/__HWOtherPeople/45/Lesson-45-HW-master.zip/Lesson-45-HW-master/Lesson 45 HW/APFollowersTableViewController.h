//
//  APFollowersTableViewController.h
//  Lesson 45 HW
//
//  Created by Alex on 01.02.16.
//  Copyright © 2016 Alex. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "APUser.h"

@interface APFollowersTableViewController : UITableViewController


// Контроллер, отображающий подписчиков

@property (strong, nonatomic) APUser* user;

@end
