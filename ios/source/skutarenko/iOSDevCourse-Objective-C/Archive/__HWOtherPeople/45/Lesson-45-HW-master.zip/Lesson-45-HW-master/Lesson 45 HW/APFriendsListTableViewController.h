//
//  APFriendsListTableViewController.h
//  Lesson 45 HW
//
//  Created by Alex on 31.01.16.
//  Copyright © 2016 Alex. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface APFriendsListTableViewController : UITableViewController

@end
