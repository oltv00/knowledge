//
//  TTDetailTableViewCell.h
//  ClientServerAPIsBasics
//
//  Created by Sergey Reshetnyak on 6/1/14.
//  Copyright (c) 2014 sergey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTDetailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *followersBtn;
@property (weak, nonatomic) IBOutlet UIButton *subscriptionsBtn;

@end
