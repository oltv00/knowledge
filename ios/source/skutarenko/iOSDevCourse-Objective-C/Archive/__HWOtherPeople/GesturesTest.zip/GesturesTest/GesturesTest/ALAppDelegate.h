//
//  ALAppDelegate.h
//  GesturesTest
//
//  Created by Линник Александр on 03.01.14.
//  Copyright (c) 2014 Alex Linnik. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ALAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
