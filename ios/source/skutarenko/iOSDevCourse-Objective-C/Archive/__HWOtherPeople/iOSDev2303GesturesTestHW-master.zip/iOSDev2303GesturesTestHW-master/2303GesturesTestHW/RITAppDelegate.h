//
//  RITAppDelegate.h
//  2303GesturesTestHW
//
//  Created by Pronin Alexander on 11.03.14.
//  Copyright (c) 2014 Pronin Alexander. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RITAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
