//
//  main.m
//  2303GesturesTestHW
//
//  Created by Pronin Alexander on 11.03.14.
//  Copyright (c) 2014 Pronin Alexander. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RITAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RITAppDelegate class]));
    }
}
