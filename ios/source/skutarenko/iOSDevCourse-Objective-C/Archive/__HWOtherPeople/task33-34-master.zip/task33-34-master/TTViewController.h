//
//  TTViewController.h
//  UITableViewNavigation
//
//  Created by sergey on 4/26/14.
//  Copyright (c) 2014 sergey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTViewController : UIViewController

- (id)initWithFolderPath:(NSString *)path;

@end
