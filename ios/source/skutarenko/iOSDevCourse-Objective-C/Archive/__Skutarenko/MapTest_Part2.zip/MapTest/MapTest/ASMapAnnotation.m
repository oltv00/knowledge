//
//  ASMapAnnotation.m
//  MapTest
//
//  Created by Oleksii Skutarenko on 11.01.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import "ASMapAnnotation.h"

@implementation ASMapAnnotation

@end
