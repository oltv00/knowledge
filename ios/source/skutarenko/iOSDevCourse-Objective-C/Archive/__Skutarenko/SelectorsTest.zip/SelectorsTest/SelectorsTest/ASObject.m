//
//  ASObject.m
//  SelectorsTest
//
//  Created by Oleksii Skutarenko on 22.10.13.
//  Copyright (c) 2013 Alex Skutarenko. All rights reserved.
//

#import "ASObject.h"

@implementation ASObject

- (void) testMethod {
    NSLog(@"ASObject testMethod");
}

- (NSString*) superSecretText {
    return @"I have stolen your candy";
}

@end
