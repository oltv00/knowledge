//
//  OTDoctor.m
//  9_DelegatesHW
//
//  Created by Oleg Tverdokhleb on 02.04.16.
//  Copyright © 2016 Oleg Tverdokhleb. All rights reserved.
//

#import "OTDoctor.h"

@interface OTDoctor ()

@property (strong, nonatomic) NSMutableDictionary *patients;

@end

@implementation OTDoctor

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.patients = [NSMutableDictionary dictionary];
        self.name = @"Doctor";
    }
    return self;
}

- (void)report {
    NSMutableArray *heads = [NSMutableArray array];
    NSMutableArray *hands = [NSMutableArray array];
    NSMutableArray *bellys = [NSMutableArray array];
    NSMutableArray *legs = [NSMutableArray array];
    
    for (NSString *key in [self.patients allKeys]) {
        switch ([self.patients[key] indexOfBodyPart]) {
            case OTPatientBodyPartHead:
                [heads addObject:self.patients[key]];
                break;
            case OTPatientBodyPartHand:
                [hands addObject:self.patients[key]];
                break;
            case OTPatientBodyPartBelly:
                [bellys addObject:self.patients[key]];
                break;
            case OTPatientBodyPartLeg:
                [legs addObject:self.patients[key]];
                break;
            default:
                break;
        }
    }
    [self printArray:heads withBodyTheme:@"heads"];
    [self printArray:hands withBodyTheme:@"hands"];
    [self printArray:bellys withBodyTheme:@"heads"];
    [self printArray:legs withBodyTheme:@"legs"];
}

- (void)printArray:(NSMutableArray *)array withBodyTheme:(NSString *)theme {
    NSLog(@"Patients with %@ curing in the amount of %ld", theme, [array count]);
    for (OTPatient *patient in array) {
        NSLog(@"%@ %@", patient.name, patient.lastName);
    }
    NSLog(@"----------------------------------------------------");
}

#pragma mark - OTPatientDelegate

- (void)patientFeelsBad:(OTPatient *)patient {
    if (!patient.isPatient) {
        NSLog(@"The doctor has a diagnosis");
        NSLog(@"%@ %@ feels bad with temperature = %1.1f", patient.name, patient.lastName, patient.temperature);
        NSLog(@"%@ %@ feels bad with body part = %@", patient.name, patient.lastName, patient.bodyPart);
        
        switch (patient.indexOfBodyPart) {
            case OTPatientBodyPartHead:
                [patient cureFromBodyPart];
                [self.patients setObject:patient
                                  forKey:[NSString stringWithFormat:@"%@%@", patient.name, patient.lastName]];
                break;
            case OTPatientBodyPartHand:
                [patient cureFromBodyPart];
                [self.patients setObject:patient
                                  forKey:[NSString stringWithFormat:@"%@%@", patient.name, patient.lastName]];
                break;
            case OTPatientBodyPartBelly:
                [self.patients setObject:patient
                                  forKey:[NSString stringWithFormat:@"%@%@", patient.name, patient.lastName]];
                [patient cureFromBodyPart];
                break;
            case OTPatientBodyPartLeg:
                [self.patients setObject:patient
                                  forKey:[NSString stringWithFormat:@"%@%@", patient.name, patient.lastName]];
                [patient cureFromBodyPart];
                break;
            default:
                break;
        }
    } else {
        NSLog(@"%@ %@ not better with temperature = %1.1f", patient.name, patient.lastName, patient.temperature);
    }
    
    if (patient.temperature >= 39.f) {
        [patient makeShot];
        [patient howAreYou];
    } else if (patient.temperature < 39.f && patient.temperature >= 37.2f) {
        [patient takePill];
        [patient howAreYou];
    } else {
        [patient shouldRest];
    }
}

@end
